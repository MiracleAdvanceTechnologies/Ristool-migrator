
# Load the JSON configuration file
$appSettings = Get-Content -Raw -Path "appsettings.json" | ConvertFrom-Json

# Extract URLs and root path from the configuration
$softwareUrls = $appSettings.SoftwareUrls
$rootPath = "$env:TEMP"

# Function to extract the file name from a URL
function GetFileNameFromUrl {
    param (
        [string]$Url
    )
    return [System.IO.Path]::GetFileName($Url)
}

# Function to download and install software
function InstallSoftware {
    param (
        [string]$Url,
        [string]$RootPath
    )

    # Extract the file name from the URL
    $fileName = GetFileNameFromUrl -Url $Url
    $outputPath = [IO.Path]::Combine($RootPath, $fileName)

    # Debugging: Check if $outputPath is valid
    Write-Host "Downloading and installing :  $fileName"

    try {
        # Download the installer
        Start-BitsTransfer -Source $Url -Destination $outputPath -ErrorAction Stop


        # Debugging: Check if the file was downloaded successfully
        if (-Not (Test-Path -Path $outputPath)) {
            throw "File download failed: $outputPath does not exist."
        }

        # Install the software
        Start-Process -FilePath $outputPath -Wait -ErrorAction Stop

        # Cleanup: Remove the installer after installation
        Remove-Item -Path $outputPath -ErrorAction Stop
    }
    catch {
        Write-Host "An error occurred: $_"
    }
}


# Install software packages
foreach ($urlProperty in $softwareUrls.PSObject.Properties) {
    InstallSoftware -Url $urlProperty.Value -RootPath $rootPath
}

Read-Host -Prompt "Press Enter to exit"
