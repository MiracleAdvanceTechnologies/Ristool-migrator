# Check if the script is running as an administrator
function Test-IsAdmin {
    $currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    return $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    Write-Host "Script is not running as an administrator. Restarting with elevated privileges..."
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    exit
}

# Enable IIS and all features
$features = @(
    "IIS-WebServerRole",
    "IIS-WebServer",
    "IIS-CommonHttpFeatures",
    "IIS-HttpErrors",
    "IIS-HttpRedirect",
    "IIS-ApplicationDevelopment",
    "IIS-NetFxExtensibility",
    "IIS-NetFxExtensibility45",
    "IIS-HealthAndDiagnostics",
    "IIS-HttpLogging",
    "IIS-LoggingLibraries",
    "IIS-RequestMonitor",
    "IIS-HttpTracing",
    "IIS-Security",
    "IIS-BasicAuthentication",
    "IIS-WindowsAuthentication",
    "IIS-DigestAuthentication",
    "IIS-ClientCertificateMappingAuthentication",
    "IIS-IISCertificateMappingAuthentication",
    "IIS-URLAuthorization",
    "IIS-RequestFiltering",
    "IIS-IPSecurity",
    "IIS-Performance",
    "IIS-HttpCompressionStatic",
    "IIS-HttpCompressionDynamic",
    "IIS-WebServerManagementTools",
    "IIS-ManagementConsole",
    "IIS-ManagementScriptingTools",
    "IIS-ManagementService",
    "IIS-IIS6ManagementCompatibility",
    "IIS-Metabase",
    "IIS-WMICompatibility",
    "IIS-LegacyScripts",
    "IIS-LegacySnapIn",
    "IIS-FTPServer",
    "IIS-FTPSvc",
    "IIS-FTPExtensibility",
    "IIS-WebDAV",
    "IIS-HostableWebCore",
    # Additional Application Development Features
    "IIS-ApplicationInit",
    "IIS-ASP",
    "IIS-ASPNET",
    "IIS-ASPNET45",
    "IIS-CGI",
    "IIS-ISAPIExtensions",
    "IIS-ISAPIFilter",
    "IIS-ServerSideIncludes",
    "IIS-WebSockets"
)

foreach ($feature in $features) {
    try {
        Write-Host "Enabling feature: $feature"
        Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -ErrorAction Stop
        Write-Host "Successfully enabled IIS feature: $feature"
        
    } catch {
        Write-Error "Failed to enable feature: $feature. Error: $_"
    }
}

Read-Host -Prompt "Press Enter to exit"
