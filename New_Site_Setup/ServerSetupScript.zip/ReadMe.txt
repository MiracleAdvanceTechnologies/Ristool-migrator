Run this command Before run the scripts

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
