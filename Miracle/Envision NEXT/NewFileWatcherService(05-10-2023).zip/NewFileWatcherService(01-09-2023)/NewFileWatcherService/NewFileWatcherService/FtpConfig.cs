﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NewFileWatcherService
{
    public class FtpConfig
    {
        public bool? IsFtpEnable { get; set; }
        public bool? IsSkipImaging { get; set; }

        public string FtpDelimiter { get; set; }
        public string FtpDelimiterPosition { get; set; }
        public string FtpMappingColumn { get; set; }
        public string Ip { get; set; }
        public string Port { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string SkipFormat { get; set; }
        public bool? WithoutAppointmentEnable { get; set; }

    }
}
