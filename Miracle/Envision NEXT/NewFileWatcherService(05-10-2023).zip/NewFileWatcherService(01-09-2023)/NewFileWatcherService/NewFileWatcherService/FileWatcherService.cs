﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Security.Policy;
using System.Web;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;

namespace NewFileWatcherService
{
    public partial class Service1 : ServiceBase
    {
        private FileSystemWatcher _fileWatcher;
        public static string mode = ConfigurationManager.AppSettings["mode"];
        public static string ftpDirectory = ConfigurationManager.AppSettings["FtpDirectory"];
        public static string appDirectory = ConfigurationManager.AppSettings["logDirectory"];
        private static FtpConfig config = new FtpConfig();
        public Service1()
        {
            InitializeComponent();
        }
        public void onDebug()
        {
            OnStart(null);
        }
        protected override void OnStart(string[] args)
        {
            StartFileWatcher();
        }

        protected override void OnStop()
        {
            StopFileWatcher();
        }

        private void StartFileWatcher()
        {
            // Initialize the FileSystemWatcher and set the properties
            _fileWatcher = new FileSystemWatcher();
            _fileWatcher.Path = ftpDirectory;
            _fileWatcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite;
            _fileWatcher.IncludeSubdirectories = true;
            // Attach event handlers for file events
            _fileWatcher.Created += OnFileCreated;
            _fileWatcher.Changed += OnFileChanged;

            // Enable raising events
            _fileWatcher.EnableRaisingEvents = true;
        }

        private void StopFileWatcher()
        {
            // Clean up and stop the FileSystemWatcher
            _fileWatcher.EnableRaisingEvents = false;
            _fileWatcher.Dispose();
        }
        private static void OnFileCreated(object sender, FileSystemEventArgs e)
        {
            Log($"new File Watched..");
            Log($"OnFileCreated: {e.FullPath}");
            string parentFolderPath = Path.GetDirectoryName(e.FullPath);
            HandleFolderCreated(parentFolderPath, e.FullPath, e.Name);
        }

        private static void OnFileChanged(object sender, FileSystemEventArgs e)
        {

        }
        private static void HandleFolderCreated(string folderPath, string fullPath, string filePath)
        {
            try
            {
                Log($"HandleFolderCreated..");
                config = getConfigData();
                string[] extentions = config.SkipFormat.Split(',');
                string fileExtension = Path.GetExtension(filePath);
                bool containsValue = extentions.Contains(fileExtension);
                FileInfo fileInfo = new FileInfo(filePath);
                string fileName = fileInfo?.Name;
                if (!containsValue)
                {
                    UploadFileToApi(fullPath, fileName, folderPath);
                }
                else
                {
                    Log($"filename : " + fileName);
                    Log($"Removed file: " + fileName + " extension " + fileExtension);

                }

            }
            catch (Exception ex)
            {
                Log($"Error handling folder '{folderPath}': {ex.Message}");
            }
        }

        private static async void UploadFileToApi(string localFilePath, string fileName, string folderPath)
        {
            try
            {
                Log($"Uploading new File..");
                Log($"UploadFileToApi fileName: {fileName}");

                string apiUrl = getUrl();
                Log($"apiUrl: {apiUrl}");
                string studyNo = getStudyNumber(folderPath);
                string folderName = Path.GetFileName(Path.GetDirectoryName(localFilePath));
                string encodedFolderName = Uri.EscapeDataString(folderName);

                // Append the folder name and file name to the API URL.
                var uploadUrl = $"{apiUrl}externalRequest/filesupload/{encodedFolderName}/{studyNo}";
                using (HttpClient httpClient = new HttpClient())
                using (MultipartFormDataContent form = new MultipartFormDataContent())
                {
                    // Read the file content into a byte array
                    Log($"read new File..");
                    int maxRetries = 10;
                    int retryDelayMilliseconds = 1000;
                    byte[] fileContent;
                    ByteArrayContent content = null;
                    for (int attempt = 1; attempt <= maxRetries; attempt++)
                    {
                        try
                        {
                            fileContent = File.ReadAllBytes(localFilePath);
                            content = new ByteArrayContent(fileContent);
                            break; // If copying succeeds, exit the loop
                        }
                        catch (IOException ex)
                        {
                            Log($"Error copying file (Attempt {attempt}/{maxRetries}): {ex.Message}");
                            if (attempt < maxRetries)
                            {
                                // Wait for a short delay before retrying
                                Thread.Sleep(retryDelayMilliseconds);
                            }
                            else
                            {
                                Log($"Max retry attempts reached. Unable to copy the file.");
                            }
                        }
                    }
                    Log($"read done..");
                    // Create a ByteArrayContent with the file content

                    // Add the file content as a form-data parameter with the filename
                    form.Add(content, "files", fileName);

                    // Send the POST request to the API endpoint
                    var response = await httpClient.PostAsync(uploadUrl, form);

                    // Check if the request was successful
                    if (response.IsSuccessStatusCode)
                    {
                        Log($"Uploaded {fileName} to API successfully.");
                    }
                    else if (response.StatusCode == HttpStatusCode.NotModified)
                    {
                        Log("Resource not modified according to the server.");
                    }
                    else if (response.StatusCode == HttpStatusCode.NotFound)
                    {
                        string msg = await response.Content.ReadAsStringAsync();
                        Log($"Failed to upload {fileName} in API: {msg}");
                    }
                    else
                    {
                        string jsonString = JsonSerializer.Serialize(response);
                        Log($"Failed to upload {fileName} 2 API. Status code: {jsonString}");
                    }
                }
            }
            catch (Exception ex)
            {
                Log($"Error uploading {fileName} to API@: {ex.Message}");
            }
        }
        private static string getUrl()
        {
            string apiUrl;
            if (mode == "prod")
            {
                apiUrl = ConfigurationManager.AppSettings["productionServer"];
            }
            else
            {
                apiUrl = ConfigurationManager.AppSettings["localServer"];
            }
            return apiUrl;
        }
        private static FtpConfig getConfigData()
        {
            try
            {
                Log($"getConfigData");
                string apiUrl = getUrl();
                int orgId = Convert.ToInt32(ConfigurationManager.AppSettings["orgId"]);
                var uploadUrl = $"{apiUrl}site/getFtpConfig/{orgId}";
                using (HttpClient httpClient = new HttpClient())
                using (MultipartFormDataContent form = new MultipartFormDataContent())
                {
                    // Send the POST request to the API endpoint
                    var response = httpClient.GetAsync(uploadUrl).Result;
                    string responseBody = response.Content.ReadAsStringAsync().Result;
                    var model = JsonSerializer.Deserialize<FtpConfig>(responseBody);
                    string jsonString = JsonSerializer.Serialize(model);
                    Log($"ftpConfigData : {jsonString}.");
                    return model;

                }
            }
            catch (Exception ex)
            {
                string jsonString = JsonSerializer.Serialize(ex);
                Log($"getConfigDataException : {jsonString}.");
                throw ex;
            }
        }

        private static string getStudyNumber(string localFilePath)
        {
            try
            {
                Log($"getStudyNumber____");
                if (config != null && config.IsFtpEnable == true)
                {
                    string study = "";
                    string rootDirectory = ftpDirectory;
                    DirectoryInfo directoryInfo = new DirectoryInfo(localFilePath);
                    DateTime currentFolderCreationTime = directoryInfo.CreationTime;
                    string currentFolderName = Path.GetFileName(localFilePath);
                    string[] parts = currentFolderName.Split(config.FtpDelimiter[0]);
                    string firstPart = parts[0];
                    string lastPart = parts[parts.Length - 1];
                    string mappingColumnValue = config.FtpDelimiterPosition != "S" ? lastPart : firstPart;
                    string studyDate = config.FtpDelimiterPosition != "S" ? firstPart : lastPart;
                    string[] subDirectories = Directory.GetDirectories(rootDirectory);
                    string jsonString = JsonSerializer.Serialize(subDirectories);
                    var folderList = new List<string>(); // Initialize an empty list to store results

                    foreach (var dir in subDirectories)
                    {
                        string nextFolderName = Path.GetFileName(dir);
                        if (!nextFolderName.Contains(config.FtpDelimiter[0]))
                        {
                            continue; // Skip this directory and move to the next iteration
                        }
                        string[] nextFolderParts = nextFolderName.Split(config.FtpDelimiter[0]);
                        string nextFolderfirstPart = nextFolderParts[0];
                        string nextFolderlastPart = nextFolderParts[parts.Length - 1];
                        string nextFolderMappingColumnValue = config.FtpDelimiterPosition != "S" ? nextFolderlastPart : nextFolderfirstPart;
                        string nextFolderStudyDate = config.FtpDelimiterPosition != "S" ? nextFolderfirstPart : nextFolderlastPart;
                        if (nextFolderName.Length >= 8 && string.Equals(nextFolderStudyDate, studyDate, StringComparison.Ordinal)
                            && string.Equals(nextFolderMappingColumnValue, mappingColumnValue, StringComparison.Ordinal))
                        {
                            folderList.Add(nextFolderName); // Add the folder to the list
                        }
                    }

                    var sortedFolderList = folderList.OrderBy(dir => Directory.GetCreationTime(dir)).ToList();
                    int index = sortedFolderList.FindIndex(dir => string.Equals(Path.GetFileName(dir), currentFolderName, StringComparison.Ordinal));
                    if (index != -1)
                    {
                        study = index.ToString();
                    }
                    else
                    {
                        study = "0";
                    }
                    string jsonString2 = JsonSerializer.Serialize(sortedFolderList);
                    Log($"study : {study}.");
                    return study;
                }
                return "0";
            }
            catch (Exception ex)
            {
                Log($"getStudyNumberException : {ex.Message}.");
                throw ex;
            }

        }
        private static void Log(string message)
        {
            string logDirectory = Path.Combine(appDirectory, "Logs");

            // Ensure the log directory exists
            Directory.CreateDirectory(logDirectory);

            // Create a log file path using the current date
            string logFileName = $"{DateTime.Now:yyyy-MM-dd}.txt";
            string logFilePath = Path.Combine(logDirectory, logFileName);

            // Write to the log file
            using (FileStream fileStream = new FileStream(logFilePath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
            using (StreamWriter writer = new StreamWriter(fileStream))
            {
                writer.WriteLine($"{DateTime.Now} - {message}");
            }
        }

    }
}
