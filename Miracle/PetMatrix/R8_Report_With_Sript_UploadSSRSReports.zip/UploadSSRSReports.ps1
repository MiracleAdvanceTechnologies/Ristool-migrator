# Set variables
$reportServerUrl = "http://petmatrix-db/ReportServer/ReportService2010.asmx?wsdl"
$targetFolder = "/PetMatrixARAK.Reporting"
$sharedDatasource = "/Data Sources/PetMatrixDataSourceARAK"
$localFolder = "E:\Reports\PetMatrix.Reporting"

# Create SSRS web service proxy
$rs = New-WebServiceProxy -Uri $reportServerUrl -UseDefaultCredential -Namespace "SSRS"

# Create folders if not exist
try { $rs.CreateFolder("PetMatrixARAK.Reporting", "/", $null) } catch {}
try { $rs.CreateFolder("Data Sources", "/", $null) } catch {}

# Loop and upload all .rdl reports
Get-ChildItem -Path $localFolder -Filter *.rdl | ForEach-Object {
    $reportName = $_.BaseName
    $rdlBytes   = [System.IO.File]::ReadAllBytes($_.FullName)
    $warnings = $null

    Write-Host "Uploading report '$reportName'..."

    # Create report (overwrite if exists)
    $rs.CreateCatalogItem(
        "Report",        # Type
        $reportName,     # Name
        $targetFolder,   # Folder
        $true,           # Overwrite
        $rdlBytes,       # Definition
        $null,           # Properties
        [ref]$warnings   # Warnings
    )

    # Link shared data source (assume only one data source per report)
    $dsRefs = $rs.GetItemReferences("$targetFolder/$reportName", "DataSource")
    if ($dsRefs.Count -gt 0) {
        $dsRef = New-Object SSRS.DataSource
        $dsRef.Name = $dsRefs[0].Name
        $dsRef.Item = New-Object SSRS.DataSourceReference
        $dsRef.Item.Reference = $sharedDatasource
        $rs.SetItemDataSources("$targetFolder/$reportName", @($dsRef))
    }
}

#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#powershell -File "E:\Reports\UploadSSRSReports.ps1"