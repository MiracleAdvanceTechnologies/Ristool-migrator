import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertifyService } from 'src/app/core/services';
import { UserService } from 'src/app/core/services/settings/user.service';
import { LayoutService } from 'src/app/layout/service/app.layout.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PwdValidatorParam, PwdValidatorRes, ResetPassword, User } from 'src/app/core/models';
import { Subject, debounceTime, distinctUntilChanged, switchMap } from 'rxjs';
import { Configuration } from 'src/app/core/models/configurations/configuration.model';
import { ConfigurationService } from 'src/app/core/services/configurations/configuration.service';
import { AuthService } from 'src/app/core/services/auth/auth.service';
import { Gblenv } from 'src/app/core/models/settings/orginfos/gblenv.model';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent  implements OnInit {

  selectedEmailOrPhoneNumber:any;
  selectedOtp: any;
  emailExists: unknown;
  config : Configuration = new Configuration();

   //Pwd Policy
    pwdPolicyOrg: Gblenv;
   isPolicyRestored: boolean = false;
   isPasswordValid: boolean;
   validationMessage: string[];
   validationMessageForTT: string;
   pwdValidatorRes: PwdValidatorRes;
   pwdValidatorParam: PwdValidatorParam = new PwdValidatorParam();
 
   isPasswordMasked: boolean = true;
  constructor(
    private userService: UserService,
    private alertify:AlertifyService,
    private router:Router,
    public layoutService: LayoutService,
    private configurationService: ConfigurationService,
    private _authService: AuthService,

  ) {}
  isSendOtp:boolean=false;
  isVerifySuccessfull:boolean=false;
  isTimeOut:boolean=false;
  selectedConfirmPassword:string;
  selectedPassword:string;
  resetForm: FormGroup;
  resetpass:ResetPassword;
  user:User;
  isLoaderVisible:boolean=false;
  searchEmailTextSubject$ = new Subject<{ email: string; Id: number }>();
  selectedPhoneCode:any;

  ngOnInit() {

    this.configurationService.getJSONwithAPI().subscribe(res=>{
      this.config = res as Configuration;
  });
    
 
  this.resetForm = new FormGroup({
   
    EmailOrPhone:new FormControl("", Validators.required),
    Password:new FormControl("", Validators.required),
    ConfirmPassword: new FormControl("", Validators.required),
   
   
  },
  { validators: this.passwordMatch }
  );

   
  }

  passwordMatch(g: FormGroup) {
    return g.get("Password").value === g.get("ConfirmPassword").value
      ? null
      : { mismatch: true };
  }



  onOtpChange(event){
    this.selectedOtp=event;
  }

  sentVerificationCode(){

    this.isLoaderVisible=true;
     this.resetpass= new ResetPassword();
    this.resetpass.Email=this.selectedEmailOrPhoneNumber;
    this.userService.requestForResetPasswordOTP(this.resetpass).subscribe(x=>{
      if(x){
        this.resetpass.ResetPasswordId=x;
        this.isSendOtp=true;

        this.isLoaderVisible=false;
      }
      else{
        this.isLoaderVisible=false;
        this.alertify.error("Failed to send OTP");
      }
    },error=>{
      this.isLoaderVisible=false;
    });
    // this.isSendOtp=true;
  }

  VerifyOtp(){
    
    this.resetpass.EmailOtp=this.selectedOtp;

    this.userService.VerifyOTP(this.resetpass).subscribe(x=>{
      if(x){
        this.user=x;
        this.isVerifySuccessfull=true;
      }
    });

  }


  UpdatePassword(){
    if (this.isPasswordValid==false) {
      this.alertify.error("Password Invalid");
      return;
    }
    this.user.Pwd=this.selectedConfirmPassword;

    this.userService.changeRadiologistPassword(this.user).subscribe(x=>{
      if(x){
        this.alertify.success("Password has been changed successfully");

        this.router.navigate(["/login"]);
      }
      else{
        this.alertify.error("Failed to reset password");

      }
    });
  }

  checkEmailOrPhoneNumber(event) {
    this.emailCheck();
    this.searchEmailTextSubject$.next({
      email: this.resetForm.controls["EmailOrPhone"].value,
      Id: 0,
    });
  }
  
  emailCheck() {
    this.searchEmailTextSubject$
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        switchMap((searchText) =>
          this.userService.emailAlreayExists(searchText.email)
        )
      )
      .subscribe((status) => {
        this.emailExists = status;
      });
  }

  isEmailValid(){
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return !re.test(String(this.selectedEmailOrPhoneNumber).toLowerCase());
  }
  // validatePassword(event) {
  //   this.pwdValidatorParam.Password=(event.target as HTMLInputElement).value;
  //   this.pwdValidatorParam.OrgId=0;
  //   if (this.pwdValidatorParam.Password !== null && this.pwdValidatorParam.Password.trim() !== '') {
  //     this._authService
  //     .ValidatePassword(this.pwdValidatorParam)
  //     .subscribe((res) => {
  //       if (res.IsSucceed) {
  //         this.pwdValidatorRes = res.Result;
  //         this.isPasswordValid=this.pwdValidatorRes.IsPasswordValid;
  //         this.validationMessage=this.pwdValidatorRes.ValidationMessage;
  //         this.validationMessageForTT=this.validationMessage.join('\n');
  //       }
  //     });
  //   }
  // }

  validatePassword(event) {
    const password = (event.target as HTMLInputElement).value.trim();
    this.pwdValidatorParam.Password = password;

    this.pwdValidatorParam.OrgId = 0;

    const validatePasswordResult = (policy) => ({
      minLength: password.length >= policy.PwdLength,
      requireUppercase: /[A-Z]/.test(password),
      requireLowercase: /[a-z]/.test(password),
      requireNumber: /\d/.test(password),
      requireSpecialChar: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    });

    if (!this.isPolicyRestored) {
      this._authService
        .GetPassPolicy(this.pwdValidatorParam.OrgId)
        .subscribe((res) => {
          if (res.IsSucceed) {
            this.pwdPolicyOrg = res.Result;
            this.isPolicyRestored = true;
            if (this.pwdPolicyOrg.PwdEnforce) {
              this.validationMessageForTT = this.generateTooltipContent(
                validatePasswordResult(this.pwdPolicyOrg),this.pwdPolicyOrg
              );
            }
          } else {
            this.isPolicyRestored = true;
          }
        });
    } else {
      if (this.pwdPolicyOrg.PwdEnforce) {
        this.validationMessageForTT = this.generateTooltipContent(
          validatePasswordResult(this.pwdPolicyOrg),this.pwdPolicyOrg
        );
      }
    }
  }

  generateTooltipContent(validationResults: any = {}, policyOrg: Gblenv): string {
    const messages = [
      {
        text: `• At least ${policyOrg.PwdLength} characters`,
        valid: validationResults.minLength || false,
        include: policyOrg.PwdLength > 0, // Include based on policyOrg property
      },
      {
        text: "• One uppercase letter",
        valid: validationResults.requireUppercase || false,
        include: policyOrg.PwdUpperCase || false,
      },
      {
        text: "• One lowercase letter",
        valid: validationResults.requireLowercase || false,
        include: policyOrg.PwdLowerCase || false,
      },
      {
        text: "• One numeric digit",
        valid: validationResults.requireNumber || false,
        include: policyOrg.PwdNumber || false,
      },
      {
        text: "• One special character",
        valid: validationResults.requireSpecialChar || false,
        include: policyOrg.PwdSpecChr || false,
      },
    ];

    this.isPasswordValid = !messages.some((message) => {
      return message.include && message.include !== message.valid;
    });
  
    
    return messages
      .filter((msg) => msg.include)
      .map(
        (msg) =>
          `<span class="${msg.valid ? 'greenColor' : 'redColor'}">${msg.text}</span>`
      )
      .join("<br/>");
  }
  
  togglePasswordMask(): void {
    this.isPasswordMasked = !this.isPasswordMasked;
  }
}

