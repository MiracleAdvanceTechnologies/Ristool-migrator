import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RouteConstant } from 'src/app/core/models';
import { LayoutService } from 'src/app/layout/service/app.layout.service';

@Component({
  selector: 'app-thank-you',
  templateUrl: './thank-you.component.html',
  styleUrls: ['./thank-you.component.scss']
})
export class ThankYouComponent {

  constructor(
    private _router: Router,
    public layoutService: LayoutService
  ){}

  redirectToAuth() {
    this._router.navigate([RouteConstant.AuthLogin]);
  }
}
