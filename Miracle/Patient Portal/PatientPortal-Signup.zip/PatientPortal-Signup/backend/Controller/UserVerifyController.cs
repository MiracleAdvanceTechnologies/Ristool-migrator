﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swift.Data;
using Swift.Repository.UserVerify.Interface;
using System.Threading.Tasks;
using System;
using Swift.API.Models;
using Swift.Repository.UserVerify.Implementation;
using Swift.Data.CustomModel;

namespace Swift.API.Controllers
{
    [ApiController]
    [Route("api/UserVerify")]
    [Produces("application/json")]
    public class UserVerifyController : ControllerBase
    {
        private readonly IUserVerifyRepository _userVerifyRepository;

        public UserVerifyController(IUserVerifyRepository UserVerifyRepository)
        {
            _userVerifyRepository = UserVerifyRepository;
        }

        [HttpPost]
        [Route("addUserVerificationInfo")]
        [AllowAnonymous]
        public async Task<IActionResult> AddUserVerifyInfo(HrEmpVerify HrEmpVerify)
        {
            try
            {
                var usrVerify = await _userVerifyRepository.AddNewUserVerify(HrEmpVerify);

                var result = new HrEmpVerify();

                if (usrVerify != null)
                {
                    result.VerifyId = usrVerify.VerifyId;
                    result.CreatedOn = usrVerify.CreatedOn;
                }

                return Ok(new CommonResponse(result));
                //return StatusCode(StatusCodes.Status201Created, result);
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        [Route("verifyOTP")]
        [AllowAnonymous]
        public async Task<IActionResult> VerifyOTP(HrEmpVerify HrEmpVerify)
        {
            try
            {
             var result=  await _userVerifyRepository.VerifyOTP(HrEmpVerify);


                return Ok(new CommonResponse(result));
               // return Ok(result);


            }
            catch (Exception)
            {

                throw;
            }
        }
    }



    
}

