﻿using Swift.Data.CustomModel.OAuth.Line;
using Swift.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Swift.API.Models;

namespace Swift.Repository.UserVerify.Interface
{
    public interface IUserVerifyRepository
    {
        Task<HrEmpVerify> AddNewUserVerify(HrEmpVerify HrEmpVerify);
        Task<HrEmpVerify> VerifyOTP(HrEmpVerify hrEmpVerify);
    }
}
