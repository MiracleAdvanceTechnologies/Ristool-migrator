﻿using SendGrid.Helpers.Mail;
using SendGrid;
using Swift.API.Models;
using Swift.Data;
using Swift.Data.CustomModel.OAuth.Line;
using Swift.Repository.UserVerify.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Microsoft.EntityFrameworkCore;
using System.Net.Http;
using Swift.Data.CustomModel.OtpMessage;
using System.Text.Json;
using Swift.Operational;
using Microsoft.Extensions.Configuration;
using Swift.Data.Configurations;
using Microsoft.Extensions.Options;
using System.Net.Mail;
using System.Net.Mime;
using System.Net.Security;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace Swift.Repository.UserVerify.Implementation
{
    public class UserVerifyRepository : IUserVerifyRepository
    {
        private readonly EnvisionhybridContext _dbContext;
        private readonly UtilityManager utilityManager;
        private readonly IConfiguration _configuration;
        public MailConfiguration _mailSettings { get; }
        public UserVerifyRepository(EnvisionhybridContext dbContext, IOptions<MailConfiguration> mailSettings, IConfiguration configuration)
        {
            _dbContext = dbContext;
            _configuration = configuration;
            utilityManager = new UtilityManager(_configuration);
            _mailSettings = mailSettings.Value;
        }
        public async Task<HrEmpVerify> AddNewUserVerify(HrEmpVerify HrVerifyEmp)
        {
            try
            {

                if (HrVerifyEmp.PhoneNo != " " && HrVerifyEmp.IsPhoneVerified!=true)
                {
                    HrVerifyEmp.PhoneOtp = generateMobileOTPBySmsMkt(HrVerifyEmp.PhoneNo, HrVerifyEmp.CountryDialCode);
                   // HrVerifyEmp.PhoneOtp = generateMobileOTP(HrVerifyEmp.PhoneNo, HrVerifyEmp.CountryDialCode);


                }

                if (HrVerifyEmp.Email != " " && HrVerifyEmp.IsEmailVerified != true)
                {
                    HrVerifyEmp.EmailOtp = await generateMailOTP(HrVerifyEmp.Email);
                }

                HrVerifyEmp.IsPhoneVerified = false;
                HrVerifyEmp.IsEmailVerified = false;
                HrVerifyEmp.CreatedOn = DateTime.Now;

                if (HrVerifyEmp.PhoneOtp != "" && HrVerifyEmp.EmailOtp != "")
                {
                    await _dbContext.HrEmpVerify.AddAsync(HrVerifyEmp);
                   await _dbContext.SaveChangesAsync();

                    _dbContext.ChangeTracker.Clear();

                     return HrVerifyEmp;
                    //return "OTP Send Successfully";

                }
                return null;



            }
            catch (Exception e)
            {

                throw e;
            }
        }

    

        private string generateMobileOTPBySmsMkt(string phone, string countryDialCode)
        {

            try
            {
                string _expire = "";
                char[] charArr = "0123456789".ToCharArray();
                string mobileOTP = string.Empty;
                Random objran = new Random();
                for (int i = 0; i < 6; i++)
                {
                    //It will not allow Repetation of Characters
                    int pos = objran.Next(1, charArr.Length);
                    if (!mobileOTP.Contains(charArr.GetValue(pos).ToString())) mobileOTP += charArr.GetValue(pos);
                    else i--;
                } 


                //var url = "https://portal-otp.smsmkt.com/api/send-message";
                var url = "https://api-inter.smsmkt.com/api/inter/send/message";

                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Post, url);

                var phoneNumber = countryDialCode + phone;

                string _apiKey = "3fb14594a263a6ee0469e5bef8a6719b";
                string _secret_key = "Xnf9xIuVONnBpoNZ";

                request.Headers.Add("api_key", _apiKey);
                request.Headers.Add("secret_key", _secret_key);                           // Mostofa bhaia : 0875061801
                var msgContent = new MessageContent
                {
                    message= $"Your OTP code {mobileOTP} will expire within 10:00 minutes.Please do not share the code to anyone else.",
                    phone=phoneNumber,
                    sender= "VetPortal",
                    expire= "01:00"
                };
                //old:
                //message= "Here is your verification code for vetportal.vet is: " + mobileOTP + "\r\nThank you.",
                var body = JsonSerializer.Serialize(msgContent);




                request.Content = new StringContent(body, Encoding.UTF8, "application/json");

                using (HttpResponseMessage response = client.SendAsync(request).Result)
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return mobileOTP;
                    }
                    else
                    {
                        throw new HttpRequestException(response.StatusCode.ToString());
                    }
                }

                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        private async Task<string> generateMailOTP(string email)
        {
            try
            {
                char[] charArr = "0123456789".ToCharArray();
                string mailOTP = string.Empty;
                Random objran = new Random();
                for (int i = 0; i < 6; i++)
                {
                    //It will not allow Repetation of Characters
                    int pos = objran.Next(1, charArr.Length);
                    if (!mailOTP.Contains(charArr.GetValue(pos).ToString())) mailOTP += charArr.GetValue(pos);
                    else i--;
                }


                //string emailFrom = "no-reply@vetportal.vet";
                //string emailFromPassword = "$1K21ke1@1o6";

                var subject = "Your verification code from Patient Portal";


                var htmlContent = $"<div style=\"font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2\">\r\n " +
                    $" <div style=\"margin:0;padding:20px 0\">\r\n   \r\n" +
                    $"    <p style=\"font-size:1.1em\">Hello,</p>\r\n " +
                    $"   <p>Here is your verification code for the Patient Portal:</p>\r\n " +
                    $"   <h2 style=\"background: #00466a;margin: 0;padding: 0 10px; width: max-content; color: #fff;border-radius: 4px;\">{mailOTP}</h2>\r\n\t<p>" +
                    $"If you haven't signed up for an account at Patient Portal you do not need to take any action</p>\r\n " +
                    $"   <p style=\"font-size:0.9em;\">Thank you</p>\r\n    <hr style=\"border:none;border-top:1px solid #eee\" />\r\n  " +
                    $" \r\n " +
                    $" </div>\r\n</div>";

                utilityManager.SendEmail(_mailSettings.From, _mailSettings.Password, email,subject, htmlContent, true, _mailSettings.Port, _mailSettings.Host,_mailSettings.DisplayName);

                //var msg = MailHelper.CreateSingleEmail(from, to, subject, "", htmlContent);
                //var response = await client.SendEmailAsync(msg);



                return mailOTP;



            }
            catch (Exception ex)
            {

                throw ex;
            }

        }




        public async Task<HrEmpVerify> VerifyOTP(HrEmpVerify hrEmpVerify)
        {
            try
            {
                var Verify = await _dbContext.HrEmpVerify.Where(x => x.VerifyId == hrEmpVerify.VerifyId && x.LastModifiedOn == null).FirstOrDefaultAsync();

                

                if (Verify != null)
                {
                    Verify.LastModifiedOn = DateTime.UtcNow;

                    if (String.Equals(Verify.PhoneOtp, hrEmpVerify.PhoneOtp))
                    {
                        Verify.IsPhoneVerified = true;
                       // Verify.LastModifiedOn = DateTime.UtcNow;

                    }

                    if (String.Equals(Verify.EmailOtp, hrEmpVerify.EmailOtp))
                    {
                        Verify.IsEmailVerified = true;
                      //  Verify.LastModifiedOn = DateTime.UtcNow;

                    }

                    await _dbContext.SaveChangesAsync();

                    return Verify;

                }

                return null;
            }
            catch (Exception)
            {

                throw;
            }
        }



        public bool SendEmail(string FromEmailAdd, string FromEmailUserPwd, string ToEmailAdd, string EmailSubject, string MessageBody, bool IsBodyHtml = false, int? PortNo = null, string HostName = "mail.radportal.net", string displayName = "", string CCEmailAdd = "", string BCCEmailAdd = "", List<Imagelist> lstimg = null, List<string> AttachmentFileUrlList = null)
        {
            bool output = false;
            //, System.Text.StringBuilder HtmlFileData = null
            try
            {

                //FromEmailAdd = FromEmailAdd ?? _configuration["EmailSetting:EmailFrom"];
                //FromEmailUserPwd = FromEmailUserPwd ?? _configuration["EmailSetting:Password"];
                //HostName = HostName ?? _configuration["EmailSetting:HostName"];
                //PortNo = PortNo ?? Convert.ToInt32(_configuration["EmailSetting:PortNo"]);
                MailMessage mailMsg = new MailMessage();

                if (!string.IsNullOrEmpty(displayName))
                {
                    mailMsg.From = new MailAddress(FromEmailAdd, displayName);
                }
                else
                {
                    mailMsg.From = new MailAddress(FromEmailAdd);
                }

                mailMsg.To.Add(ToEmailAdd);
                if (CCEmailAdd != "")
                    mailMsg.CC.Add(CCEmailAdd);
                if (BCCEmailAdd != "")
                    mailMsg.Bcc.Add(BCCEmailAdd);





                mailMsg.Subject = EmailSubject;

                if (IsBodyHtml == false)
                {
                    mailMsg.Body = MessageBody;
                }
                else if (IsBodyHtml == true)
                {
                    mailMsg.IsBodyHtml = true;

                    string body = MessageBody;
                    //HtmlFileData.ToString();

                    mailMsg.Body = body;



                    if (lstimg != null)
                    {
                        //AlternateView avHtml = null;
                        AlternateView avHtml = AlternateView.CreateAlternateViewFromString(body, null, MediaTypeNames.Text.Html);
                        LinkedResource pic1 = null;
                        foreach (var itm in lstimg)
                        {
                            string imageurl = (itm.ImageUrl == null ? "" : itm.ImageUrl);
                            string ImageLinkName = itm.ImageLinkName;

                            if (imageurl != "")
                            {
                                pic1 = new LinkedResource(imageurl, MediaTypeNames.Image.Jpeg);
                            }
                            else
                            {
                                if (itm.ImageStream != null)
                                {
                                    pic1 = new LinkedResource(itm.ImageStream);
                                }
                            }

                            pic1.ContentId = ImageLinkName;
                            avHtml.LinkedResources.Add(pic1);

                        }
                        mailMsg.AlternateViews.Add(avHtml);
                    }
                }

                #region Attachment

                if (AttachmentFileUrlList != null && AttachmentFileUrlList.Count > 0)
                {
                    foreach (var itm in AttachmentFileUrlList)
                    {
                        mailMsg.Attachments.Add(new System.Net.Mail.Attachment(itm));
                    }

                }

                #endregion

                mailMsg.Priority = MailPriority.Normal;
                SmtpClient client = new SmtpClient();
                client.Credentials = new System.Net.NetworkCredential(FromEmailAdd, FromEmailUserPwd);
                //client.Port = 587;
                client.Port = (PortNo == null ? 465 : Convert.ToInt32(PortNo)); //or use 465           
                client.Host = HostName;//"smtp.gmail.com";
                client.EnableSsl = true;
                object userState = mailMsg;
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                client.Send(mailMsg);
                output = true;
            }
            catch (Exception ex)
            {
                //WriteTextToLocalDive($"SendEmail Error-{ex}");
                throw ex;
            }
            //WriteTextToLocalDive($"SendEmail: Send Email Success, {ToEmailAdd}");
            return output;
        }





    }
}
