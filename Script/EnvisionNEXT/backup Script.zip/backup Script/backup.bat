@echo off

:: Set variables
set dbname=NEXT_DB_CLOUD_V2
set dbuser=postgres
set dbhost=localhost
set dbport=5434
set backupdir=L:\Backup_DB
set pgpath=C:\Program Files\PostgreSQL\14\bin

:: Get the current date and time
for /f "tokens=1-4 delims=/-. " %%a in ("%date%") do (
    set year=%%d
    set month=%%b
    set day=%%c
)

:: Get the current time
for /f "tokens=1-3 delims=:., " %%a in ("%time%") do (
    set hour=%%a
    set minute=%%b
    set second=%%c
)

:: Remove invalid characters from time variables
set hour=%hour::=%
set minute=%minute::=%
set second=%second::=%

:: Format the date and time

set datetime=%year%-%month%-%day%_%hour%-%minute%-%second%
set dateOnly=%year%-%month%-%day%
set backupfile=%backupdir%\%dateOnly%\%dbname%_%datetime%.sql

:: Set the PostgreSQL password environment variable
set PGPASSWORD=12345

:: Create backup directory if it doesn't exist
if not exist "%backupdir%\%dateOnly%" mkdir "%backupdir%\%dateOnly%"

:: Perform the backup
"%pgpath%\pg_dump" -h %dbhost% -p %dbport% -U %dbuser% -F c -b -v -f "%backupfile%" %dbname% 2>error.log

:: Check if the backup was successful
if %ERRORLEVEL% NEQ 0 (
    echo Backup failed!
    type error.log
    exit /b %ERRORLEVEL%
) else (
    echo Backup successful: %backupfile%
)

:: Clean up the password environment variable
set PGPASSWORD=


