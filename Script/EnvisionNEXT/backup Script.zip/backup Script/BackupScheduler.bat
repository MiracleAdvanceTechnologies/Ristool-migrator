@echo off
set taskname=EnvisionNext_DB_Backup
set batchfile=D:\Snap_Published_Files\backup Script\backup.bat

REM Delete the task if it already exists
schtasks /delete /tn %taskname% /f

REM Create the task with the first trigger (08:00 AM)
schtasks /create /tn %taskname% /tr "%batchfile%" /sc daily /st 08:00 /f

REM Add the second trigger (02:00 PM)
schtasks /create /tn %taskname%-2 /tr "%batchfile%" /sc daily /st 14:00 /f

REM Add the third trigger (08:00 PM)
schtasks /create /tn %taskname%-3 /tr "%batchfile%" /sc daily /st 20:00 /f

echo Task scheduled to run three times a day.
pause



