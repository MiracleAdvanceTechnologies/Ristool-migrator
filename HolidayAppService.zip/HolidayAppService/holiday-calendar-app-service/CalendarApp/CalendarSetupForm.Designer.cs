﻿
namespace CalendarApp
{
    partial class CalendarSetupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CalendarSetupForm));
            this.label1 = new System.Windows.Forms.Label();
            this.urlTextBox = new System.Windows.Forms.TextBox();
            this.UploadBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.MondayStartTime = new System.Windows.Forms.DateTimePicker();
            this.MondayEndTime = new System.Windows.Forms.DateTimePicker();
            this.SaturdayEndTime = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.saveBtn = new System.Windows.Forms.Button();
            this.TuesDayStartTime = new System.Windows.Forms.DateTimePicker();
            this.WednesDayStartTime = new System.Windows.Forms.DateTimePicker();
            this.ThursDayStartTime = new System.Windows.Forms.DateTimePicker();
            this.FriDayStartTime = new System.Windows.Forms.DateTimePicker();
            this.SaturDayStartTime = new System.Windows.Forms.DateTimePicker();
            this.TuesdayEndTime = new System.Windows.Forms.DateTimePicker();
            this.WednesdayEndTime = new System.Windows.Forms.DateTimePicker();
            this.ThursdayEndTime = new System.Windows.Forms.DateTimePicker();
            this.FridayEndTime = new System.Windows.Forms.DateTimePicker();
            this.SunDayStartTime = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.SunDayEndTime = new System.Windows.Forms.DateTimePicker();
            this.MondayCheckBox = new System.Windows.Forms.CheckBox();
            this.TuesdayCheckBox = new System.Windows.Forms.CheckBox();
            this.WednesdayCheckBox = new System.Windows.Forms.CheckBox();
            this.FridayCheckBox = new System.Windows.Forms.CheckBox();
            this.ThursdayCheckBox = new System.Windows.Forms.CheckBox();
            this.SaturdayCheckBox = new System.Windows.Forms.CheckBox();
            this.SundayCheckBox = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.yesCheckBox = new System.Windows.Forms.CheckBox();
            this.noCheckBox = new System.Windows.Forms.CheckBox();
            this.checkBox1month = new System.Windows.Forms.CheckBox();
            this.checkBox3month = new System.Windows.Forms.CheckBox();
            this.checkBox6month = new System.Windows.Forms.CheckBox();
            this.checkBox12month = new System.Windows.Forms.CheckBox();
            this.frequencySaveButton = new System.Windows.Forms.Button();
            this.updateTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.frequencyPanel = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lastUpdateGroupBox = new System.Windows.Forms.GroupBox();
            this.lastImportLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.frequencyPanel.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.lastUpdateGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Holiday Calendar URL  :";
            // 
            // urlTextBox
            // 
            this.urlTextBox.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.urlTextBox.Location = new System.Drawing.Point(188, 21);
            this.urlTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.urlTextBox.Name = "urlTextBox";
            this.urlTextBox.Size = new System.Drawing.Size(458, 25);
            this.urlTextBox.TabIndex = 1;
            // 
            // UploadBtn
            // 
            this.UploadBtn.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UploadBtn.Location = new System.Drawing.Point(670, 17);
            this.UploadBtn.Margin = new System.Windows.Forms.Padding(4);
            this.UploadBtn.Name = "UploadBtn";
            this.UploadBtn.Size = new System.Drawing.Size(112, 32);
            this.UploadBtn.TabIndex = 2;
            this.UploadBtn.Text = "Import";
            this.UploadBtn.UseVisualStyleBackColor = true;
            this.UploadBtn.Click += new System.EventHandler(this.UploadBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label2.Location = new System.Drawing.Point(14, 78);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 19);
            this.label2.TabIndex = 4;
            this.label2.Text = "Start Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label3.Location = new System.Drawing.Point(244, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tuesday";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label4.Location = new System.Drawing.Point(128, 43);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Monday";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label5.Location = new System.Drawing.Point(357, 43);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "Wednesday";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label6.Location = new System.Drawing.Point(500, 43);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "Thursday";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label7.Location = new System.Drawing.Point(628, 43);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 19);
            this.label7.TabIndex = 9;
            this.label7.Text = "Friday";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label8.Location = new System.Drawing.Point(14, 119);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 19);
            this.label8.TabIndex = 10;
            this.label8.Text = "End Time";
            // 
            // MondayStartTime
            // 
            this.MondayStartTime.CustomFormat = "hh:mm tt";
            this.MondayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.MondayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.MondayStartTime.Location = new System.Drawing.Point(106, 74);
            this.MondayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MondayStartTime.Name = "MondayStartTime";
            this.MondayStartTime.ShowUpDown = true;
            this.MondayStartTime.Size = new System.Drawing.Size(92, 25);
            this.MondayStartTime.TabIndex = 21;
            this.MondayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            // 
            // MondayEndTime
            // 
            this.MondayEndTime.CustomFormat = "hh:mm tt";
            this.MondayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.MondayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.MondayEndTime.Location = new System.Drawing.Point(106, 116);
            this.MondayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MondayEndTime.Name = "MondayEndTime";
            this.MondayEndTime.ShowUpDown = true;
            this.MondayEndTime.Size = new System.Drawing.Size(92, 25);
            this.MondayEndTime.TabIndex = 22;
            this.MondayEndTime.Value = new System.DateTime(2022, 3, 25, 17, 0, 0, 0);
            // 
            // SaturdayEndTime
            // 
            this.SaturdayEndTime.CustomFormat = "hh:mm tt";
            this.SaturdayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.SaturdayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.SaturdayEndTime.Location = new System.Drawing.Point(710, 116);
            this.SaturdayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SaturdayEndTime.Name = "SaturdayEndTime";
            this.SaturdayEndTime.ShowUpDown = true;
            this.SaturdayEndTime.Size = new System.Drawing.Size(92, 25);
            this.SaturdayEndTime.TabIndex = 31;
            this.SaturdayEndTime.Value = new System.DateTime(2022, 3, 25, 12, 30, 0, 0);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label10.Location = new System.Drawing.Point(730, 43);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 19);
            this.label10.TabIndex = 32;
            this.label10.Text = "Saturday";
            // 
            // saveBtn
            // 
            this.saveBtn.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.Location = new System.Drawing.Point(774, 165);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(142, 33);
            this.saveBtn.TabIndex = 33;
            this.saveBtn.Text = "Save";
            this.saveBtn.UseVisualStyleBackColor = true;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // TuesDayStartTime
            // 
            this.TuesDayStartTime.CustomFormat = "hh:mm tt";
            this.TuesDayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.TuesDayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TuesDayStartTime.Location = new System.Drawing.Point(222, 74);
            this.TuesDayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TuesDayStartTime.Name = "TuesDayStartTime";
            this.TuesDayStartTime.ShowUpDown = true;
            this.TuesDayStartTime.Size = new System.Drawing.Size(92, 25);
            this.TuesDayStartTime.TabIndex = 34;
            this.TuesDayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            // 
            // WednesDayStartTime
            // 
            this.WednesDayStartTime.CustomFormat = "hh:mm tt";
            this.WednesDayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.WednesDayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.WednesDayStartTime.Location = new System.Drawing.Point(336, 74);
            this.WednesDayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.WednesDayStartTime.Name = "WednesDayStartTime";
            this.WednesDayStartTime.ShowUpDown = true;
            this.WednesDayStartTime.Size = new System.Drawing.Size(114, 25);
            this.WednesDayStartTime.TabIndex = 35;
            this.WednesDayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            // 
            // ThursDayStartTime
            // 
            this.ThursDayStartTime.CustomFormat = "hh:mm tt";
            this.ThursDayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.ThursDayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ThursDayStartTime.Location = new System.Drawing.Point(476, 74);
            this.ThursDayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ThursDayStartTime.Name = "ThursDayStartTime";
            this.ThursDayStartTime.ShowUpDown = true;
            this.ThursDayStartTime.Size = new System.Drawing.Size(97, 25);
            this.ThursDayStartTime.TabIndex = 36;
            this.ThursDayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            // 
            // FriDayStartTime
            // 
            this.FriDayStartTime.CustomFormat = "hh:mm tt";
            this.FriDayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.FriDayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.FriDayStartTime.Location = new System.Drawing.Point(602, 74);
            this.FriDayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FriDayStartTime.Name = "FriDayStartTime";
            this.FriDayStartTime.ShowUpDown = true;
            this.FriDayStartTime.Size = new System.Drawing.Size(92, 25);
            this.FriDayStartTime.TabIndex = 37;
            this.FriDayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            // 
            // SaturDayStartTime
            // 
            this.SaturDayStartTime.CustomFormat = "hh:mm tt";
            this.SaturDayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.SaturDayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.SaturDayStartTime.Location = new System.Drawing.Point(710, 74);
            this.SaturDayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SaturDayStartTime.Name = "SaturDayStartTime";
            this.SaturDayStartTime.ShowUpDown = true;
            this.SaturDayStartTime.Size = new System.Drawing.Size(92, 25);
            this.SaturDayStartTime.TabIndex = 38;
            this.SaturDayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            // 
            // TuesdayEndTime
            // 
            this.TuesdayEndTime.CustomFormat = "hh:mm tt";
            this.TuesdayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.TuesdayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TuesdayEndTime.Location = new System.Drawing.Point(222, 116);
            this.TuesdayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TuesdayEndTime.Name = "TuesdayEndTime";
            this.TuesdayEndTime.ShowUpDown = true;
            this.TuesdayEndTime.Size = new System.Drawing.Size(92, 25);
            this.TuesdayEndTime.TabIndex = 39;
            this.TuesdayEndTime.Value = new System.DateTime(2022, 3, 25, 17, 0, 0, 0);
            // 
            // WednesdayEndTime
            // 
            this.WednesdayEndTime.CustomFormat = "hh:mm tt";
            this.WednesdayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.WednesdayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.WednesdayEndTime.Location = new System.Drawing.Point(336, 116);
            this.WednesdayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.WednesdayEndTime.Name = "WednesdayEndTime";
            this.WednesdayEndTime.ShowUpDown = true;
            this.WednesdayEndTime.Size = new System.Drawing.Size(114, 25);
            this.WednesdayEndTime.TabIndex = 40;
            this.WednesdayEndTime.Value = new System.DateTime(2022, 3, 25, 17, 0, 0, 0);
            // 
            // ThursdayEndTime
            // 
            this.ThursdayEndTime.CustomFormat = "hh:mm tt";
            this.ThursdayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.ThursdayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.ThursdayEndTime.Location = new System.Drawing.Point(476, 116);
            this.ThursdayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ThursdayEndTime.Name = "ThursdayEndTime";
            this.ThursdayEndTime.ShowUpDown = true;
            this.ThursdayEndTime.Size = new System.Drawing.Size(97, 25);
            this.ThursdayEndTime.TabIndex = 41;
            this.ThursdayEndTime.Value = new System.DateTime(2022, 3, 25, 17, 0, 0, 0);
            // 
            // FridayEndTime
            // 
            this.FridayEndTime.CustomFormat = "hh:mm tt";
            this.FridayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.FridayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.FridayEndTime.Location = new System.Drawing.Point(602, 116);
            this.FridayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FridayEndTime.Name = "FridayEndTime";
            this.FridayEndTime.ShowUpDown = true;
            this.FridayEndTime.Size = new System.Drawing.Size(92, 25);
            this.FridayEndTime.TabIndex = 42;
            this.FridayEndTime.Value = new System.DateTime(2022, 3, 25, 17, 0, 0, 0);
            // 
            // SunDayStartTime
            // 
            this.SunDayStartTime.CustomFormat = "hh:mm tt";
            this.SunDayStartTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.SunDayStartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.SunDayStartTime.Location = new System.Drawing.Point(824, 74);
            this.SunDayStartTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SunDayStartTime.Name = "SunDayStartTime";
            this.SunDayStartTime.ShowUpDown = true;
            this.SunDayStartTime.Size = new System.Drawing.Size(92, 25);
            this.SunDayStartTime.TabIndex = 45;
            this.SunDayStartTime.Value = new System.DateTime(2022, 3, 25, 8, 30, 0, 0);
            this.SunDayStartTime.ValueChanged += new System.EventHandler(this.SunDayStartTime_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.label11.Location = new System.Drawing.Point(844, 43);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 19);
            this.label11.TabIndex = 44;
            this.label11.Text = "Sunday";
            // 
            // SunDayEndTime
            // 
            this.SunDayEndTime.CustomFormat = "hh:mm tt";
            this.SunDayEndTime.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.SunDayEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.SunDayEndTime.Location = new System.Drawing.Point(824, 116);
            this.SunDayEndTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SunDayEndTime.Name = "SunDayEndTime";
            this.SunDayEndTime.ShowUpDown = true;
            this.SunDayEndTime.Size = new System.Drawing.Size(92, 25);
            this.SunDayEndTime.TabIndex = 43;
            this.SunDayEndTime.Value = new System.DateTime(2022, 3, 25, 12, 30, 0, 0);
            // 
            // MondayCheckBox
            // 
            this.MondayCheckBox.AutoSize = true;
            this.MondayCheckBox.Location = new System.Drawing.Point(106, 45);
            this.MondayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MondayCheckBox.Name = "MondayCheckBox";
            this.MondayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.MondayCheckBox.TabIndex = 47;
            this.MondayCheckBox.UseVisualStyleBackColor = true;
            this.MondayCheckBox.CheckedChanged += new System.EventHandler(this.MondayCheckBox_CheckedChanged);
            // 
            // TuesdayCheckBox
            // 
            this.TuesdayCheckBox.AutoSize = true;
            this.TuesdayCheckBox.Location = new System.Drawing.Point(222, 45);
            this.TuesdayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TuesdayCheckBox.Name = "TuesdayCheckBox";
            this.TuesdayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.TuesdayCheckBox.TabIndex = 48;
            this.TuesdayCheckBox.UseVisualStyleBackColor = true;
            this.TuesdayCheckBox.CheckedChanged += new System.EventHandler(this.TuesdayCheckBox_CheckedChanged);
            // 
            // WednesdayCheckBox
            // 
            this.WednesdayCheckBox.AutoSize = true;
            this.WednesdayCheckBox.Location = new System.Drawing.Point(334, 45);
            this.WednesdayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.WednesdayCheckBox.Name = "WednesdayCheckBox";
            this.WednesdayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.WednesdayCheckBox.TabIndex = 49;
            this.WednesdayCheckBox.UseVisualStyleBackColor = true;
            this.WednesdayCheckBox.CheckedChanged += new System.EventHandler(this.WednesdayCheckBox_CheckedChanged);
            // 
            // FridayCheckBox
            // 
            this.FridayCheckBox.AutoSize = true;
            this.FridayCheckBox.Location = new System.Drawing.Point(602, 45);
            this.FridayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FridayCheckBox.Name = "FridayCheckBox";
            this.FridayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.FridayCheckBox.TabIndex = 50;
            this.FridayCheckBox.UseVisualStyleBackColor = true;
            this.FridayCheckBox.CheckedChanged += new System.EventHandler(this.FridayCheckBox_CheckedChanged);
            // 
            // ThursdayCheckBox
            // 
            this.ThursdayCheckBox.AutoSize = true;
            this.ThursdayCheckBox.Location = new System.Drawing.Point(476, 45);
            this.ThursdayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ThursdayCheckBox.Name = "ThursdayCheckBox";
            this.ThursdayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.ThursdayCheckBox.TabIndex = 51;
            this.ThursdayCheckBox.UseVisualStyleBackColor = true;
            this.ThursdayCheckBox.CheckedChanged += new System.EventHandler(this.ThursdayCheckBox_CheckedChanged);
            // 
            // SaturdayCheckBox
            // 
            this.SaturdayCheckBox.AutoSize = true;
            this.SaturdayCheckBox.Location = new System.Drawing.Point(710, 45);
            this.SaturdayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SaturdayCheckBox.Name = "SaturdayCheckBox";
            this.SaturdayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.SaturdayCheckBox.TabIndex = 52;
            this.SaturdayCheckBox.UseVisualStyleBackColor = true;
            this.SaturdayCheckBox.CheckedChanged += new System.EventHandler(this.SaturdayCheckBox_CheckedChanged);
            // 
            // SundayCheckBox
            // 
            this.SundayCheckBox.AutoSize = true;
            this.SundayCheckBox.Location = new System.Drawing.Point(824, 45);
            this.SundayCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SundayCheckBox.Name = "SundayCheckBox";
            this.SundayCheckBox.Size = new System.Drawing.Size(15, 14);
            this.SundayCheckBox.TabIndex = 53;
            this.SundayCheckBox.UseVisualStyleBackColor = true;
            this.SundayCheckBox.CheckedChanged += new System.EventHandler(this.SundayCheckBox_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 28);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 19);
            this.label12.TabIndex = 54;
            // 
            // yesCheckBox
            // 
            this.yesCheckBox.AutoSize = true;
            this.yesCheckBox.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yesCheckBox.Location = new System.Drawing.Point(132, 25);
            this.yesCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.yesCheckBox.Name = "yesCheckBox";
            this.yesCheckBox.Size = new System.Drawing.Size(49, 23);
            this.yesCheckBox.TabIndex = 55;
            this.yesCheckBox.Text = "Yes";
            this.yesCheckBox.UseVisualStyleBackColor = true;
            this.yesCheckBox.CheckedChanged += new System.EventHandler(this.yesCheckBox_CheckedChanged);
            // 
            // noCheckBox
            // 
            this.noCheckBox.AutoSize = true;
            this.noCheckBox.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noCheckBox.Location = new System.Drawing.Point(212, 25);
            this.noCheckBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.noCheckBox.Name = "noCheckBox";
            this.noCheckBox.Size = new System.Drawing.Size(47, 23);
            this.noCheckBox.TabIndex = 56;
            this.noCheckBox.Text = "No";
            this.noCheckBox.UseVisualStyleBackColor = true;
            this.noCheckBox.CheckedChanged += new System.EventHandler(this.noCheckBox_CheckedChanged);
            // 
            // checkBox1month
            // 
            this.checkBox1month.AutoSize = true;
            this.checkBox1month.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1month.Location = new System.Drawing.Point(130, 25);
            this.checkBox1month.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox1month.Name = "checkBox1month";
            this.checkBox1month.Size = new System.Drawing.Size(82, 23);
            this.checkBox1month.TabIndex = 58;
            this.checkBox1month.Text = "1 Month";
            this.checkBox1month.UseVisualStyleBackColor = true;
            this.checkBox1month.CheckedChanged += new System.EventHandler(this.checkBox1month_CheckedChanged);
            // 
            // checkBox3month
            // 
            this.checkBox3month.AutoSize = true;
            this.checkBox3month.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3month.Location = new System.Drawing.Point(230, 25);
            this.checkBox3month.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox3month.Name = "checkBox3month";
            this.checkBox3month.Size = new System.Drawing.Size(82, 23);
            this.checkBox3month.TabIndex = 59;
            this.checkBox3month.Text = "3 Month";
            this.checkBox3month.UseVisualStyleBackColor = true;
            this.checkBox3month.CheckedChanged += new System.EventHandler(this.checkBox3month_CheckedChanged);
            // 
            // checkBox6month
            // 
            this.checkBox6month.AutoSize = true;
            this.checkBox6month.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6month.Location = new System.Drawing.Point(328, 25);
            this.checkBox6month.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox6month.Name = "checkBox6month";
            this.checkBox6month.Size = new System.Drawing.Size(82, 23);
            this.checkBox6month.TabIndex = 60;
            this.checkBox6month.Text = "6 Month";
            this.checkBox6month.UseVisualStyleBackColor = true;
            this.checkBox6month.CheckedChanged += new System.EventHandler(this.checkBox6month_CheckedChanged);
            // 
            // checkBox12month
            // 
            this.checkBox12month.AutoSize = true;
            this.checkBox12month.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox12month.Location = new System.Drawing.Point(430, 25);
            this.checkBox12month.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox12month.Name = "checkBox12month";
            this.checkBox12month.Size = new System.Drawing.Size(90, 23);
            this.checkBox12month.TabIndex = 61;
            this.checkBox12month.Text = "12 Month";
            this.checkBox12month.UseVisualStyleBackColor = true;
            this.checkBox12month.CheckedChanged += new System.EventHandler(this.checkBox12month_CheckedChanged);
            // 
            // frequencySaveButton
            // 
            this.frequencySaveButton.Enabled = false;
            this.frequencySaveButton.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frequencySaveButton.Location = new System.Drawing.Point(670, 20);
            this.frequencySaveButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.frequencySaveButton.Name = "frequencySaveButton";
            this.frequencySaveButton.Size = new System.Drawing.Size(112, 31);
            this.frequencySaveButton.TabIndex = 62;
            this.frequencySaveButton.Text = "Save";
            this.frequencySaveButton.UseVisualStyleBackColor = true;
            this.frequencySaveButton.Click += new System.EventHandler(this.frequencySaveButton_Click);
            // 
            // updateTimer
            // 
            this.updateTimer.Enabled = true;
            this.updateTimer.Interval = 14400000;
            this.updateTimer.Tick += new System.EventHandler(this.updateTimer_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.urlTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.UploadBtn);
            this.groupBox1.Location = new System.Drawing.Point(16, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(800, 62);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.frequencySaveButton);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.yesCheckBox);
            this.groupBox2.Controls.Add(this.noCheckBox);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(16, 75);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(800, 62);
            this.groupBox2.TabIndex = 65;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Auto Update";
            // 
            // frequencyPanel
            // 
            this.frequencyPanel.Controls.Add(this.checkBox12month);
            this.frequencyPanel.Controls.Add(this.checkBox3month);
            this.frequencyPanel.Controls.Add(this.checkBox1month);
            this.frequencyPanel.Controls.Add(this.checkBox6month);
            this.frequencyPanel.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frequencyPanel.Location = new System.Drawing.Point(16, 138);
            this.frequencyPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.frequencyPanel.Name = "frequencyPanel";
            this.frequencyPanel.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.frequencyPanel.Size = new System.Drawing.Size(800, 62);
            this.frequencyPanel.TabIndex = 66;
            this.frequencyPanel.TabStop = false;
            this.frequencyPanel.Text = "Frequency";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.MondayCheckBox);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.SundayCheckBox);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.SaturdayCheckBox);
            this.groupBox3.Controls.Add(this.ThursdayCheckBox);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.FridayCheckBox);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.WednesdayCheckBox);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.TuesdayCheckBox);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.MondayStartTime);
            this.groupBox3.Controls.Add(this.SunDayStartTime);
            this.groupBox3.Controls.Add(this.MondayEndTime);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.SaturdayEndTime);
            this.groupBox3.Controls.Add(this.SunDayEndTime);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.FridayEndTime);
            this.groupBox3.Controls.Add(this.saveBtn);
            this.groupBox3.Controls.Add(this.ThursdayEndTime);
            this.groupBox3.Controls.Add(this.TuesDayStartTime);
            this.groupBox3.Controls.Add(this.WednesdayEndTime);
            this.groupBox3.Controls.Add(this.WednesDayStartTime);
            this.groupBox3.Controls.Add(this.TuesdayEndTime);
            this.groupBox3.Controls.Add(this.ThursDayStartTime);
            this.groupBox3.Controls.Add(this.SaturDayStartTime);
            this.groupBox3.Controls.Add(this.FriDayStartTime);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(16, 288);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(932, 213);
            this.groupBox3.TabIndex = 67;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Office Time Setup";
            // 
            // lastUpdateGroupBox
            // 
            this.lastUpdateGroupBox.Controls.Add(this.lastImportLabel);
            this.lastUpdateGroupBox.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastUpdateGroupBox.Location = new System.Drawing.Point(16, 204);
            this.lastUpdateGroupBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lastUpdateGroupBox.Name = "lastUpdateGroupBox";
            this.lastUpdateGroupBox.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lastUpdateGroupBox.Size = new System.Drawing.Size(802, 47);
            this.lastUpdateGroupBox.TabIndex = 68;
            this.lastUpdateGroupBox.TabStop = false;
            this.lastUpdateGroupBox.Text = "Last Import Time";
            // 
            // lastImportLabel
            // 
            this.lastImportLabel.AutoSize = true;
            this.lastImportLabel.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F);
            this.lastImportLabel.Location = new System.Drawing.Point(128, 26);
            this.lastImportLabel.Name = "lastImportLabel";
            this.lastImportLabel.Size = new System.Drawing.Size(0, 19);
            this.lastImportLabel.TabIndex = 0;
            // 
            // CalendarSetupForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 535);
            this.Controls.Add(this.lastUpdateGroupBox);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.frequencyPanel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "CalendarSetupForm";
            this.Text = "Calendar Setup Form";
            this.Load += new System.EventHandler(this.CalendarSetupForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.frequencyPanel.ResumeLayout(false);
            this.frequencyPanel.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.lastUpdateGroupBox.ResumeLayout(false);
            this.lastUpdateGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox urlTextBox;
        private System.Windows.Forms.Button UploadBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker MondayStartTime;
        private System.Windows.Forms.DateTimePicker MondayEndTime;
        private System.Windows.Forms.DateTimePicker SaturdayEndTime;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.DateTimePicker TuesDayStartTime;
        private System.Windows.Forms.DateTimePicker WednesDayStartTime;
        private System.Windows.Forms.DateTimePicker ThursDayStartTime;
        private System.Windows.Forms.DateTimePicker FriDayStartTime;
        private System.Windows.Forms.DateTimePicker SaturDayStartTime;
        private System.Windows.Forms.DateTimePicker TuesdayEndTime;
        private System.Windows.Forms.DateTimePicker WednesdayEndTime;
        private System.Windows.Forms.DateTimePicker ThursdayEndTime;
        private System.Windows.Forms.DateTimePicker FridayEndTime;
        private System.Windows.Forms.DateTimePicker SunDayStartTime;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker SunDayEndTime;
        private System.Windows.Forms.CheckBox MondayCheckBox;
        private System.Windows.Forms.CheckBox TuesdayCheckBox;
        private System.Windows.Forms.CheckBox WednesdayCheckBox;
        private System.Windows.Forms.CheckBox FridayCheckBox;
        private System.Windows.Forms.CheckBox ThursdayCheckBox;
        private System.Windows.Forms.CheckBox SaturdayCheckBox;
        private System.Windows.Forms.CheckBox SundayCheckBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox yesCheckBox;
        private System.Windows.Forms.CheckBox noCheckBox;
        private System.Windows.Forms.CheckBox checkBox1month;
        private System.Windows.Forms.CheckBox checkBox3month;
        private System.Windows.Forms.CheckBox checkBox6month;
        private System.Windows.Forms.CheckBox checkBox12month;
        private System.Windows.Forms.Button frequencySaveButton;
        private System.Windows.Forms.Timer updateTimer;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox frequencyPanel;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox lastUpdateGroupBox;
        private System.Windows.Forms.Label lastImportLabel;
    }
}