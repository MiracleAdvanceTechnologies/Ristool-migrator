﻿using System;

namespace CalendarApp.Model
{
    public partial class GblHoliday
    {
        public int HolidayId { get; set; }
        public DateTime? HolidayDate { get; set; }
        public string HolidayDesc { get; set; }
        public bool? IsActive { get; set; } = true;
        public int? OrgId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public int? LastModifiedBy { get; set; }
        public DateTime? LastModifiedOn { get; set; }
        public bool? IsBlock { get; set; } = false;
        public int? RoomId { get; set; }

    }
}