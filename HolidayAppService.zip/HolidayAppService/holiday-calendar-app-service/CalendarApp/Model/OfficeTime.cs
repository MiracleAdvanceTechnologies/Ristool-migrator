﻿namespace CalendarApp.Model
{
    public class OfficeTime
    {

    }
}
