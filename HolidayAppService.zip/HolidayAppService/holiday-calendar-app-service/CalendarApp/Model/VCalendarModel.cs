﻿using System;

namespace CalendarApp.Model
{
    public class VCalendarModel
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public string description { get; set; }
    }
}
