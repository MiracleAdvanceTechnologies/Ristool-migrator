﻿using Microsoft.Win32;
using System;

namespace CalendarApp.Model
{
    public class RegHelper
    {

        public RegHelper()
        {

        }

        /// <summary>
        /// Check run on startup status
        /// </summary>
        /// <returns></returns>
        public static bool IsRunOnStartup()
        {
            bool isStartup = false;
            RegistryKey key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", false);

            try
            {
                if (key.GetValue("DICOMRouterAI") != null)
                    isStartup = true;
            }
            catch (NullReferenceException)
            {
            }

            key.Close();
            return isStartup;
        }

        /// <summary>
        /// Set or remove run on startup
        /// </summary>
        /// <param name="path"></param>
        /// <param name="remove"></param>
        public static void SetRunOnStartup(string path, bool remove)
        {
            RegistryKey key;
            if (Environment.Is64BitOperatingSystem)
            {
                 key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run", true);
            }
            else
            {
                key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", false);
            }
            if (!remove)
                try
                {
                    key.SetValue("calendarAppKey", path);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            else
                key.DeleteValue("calendarAppKey", false);

            key.Close();
        }







    }
}