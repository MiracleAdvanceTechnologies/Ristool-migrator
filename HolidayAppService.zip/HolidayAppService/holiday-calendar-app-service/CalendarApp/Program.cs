﻿using CalendarApp.Model;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace CalendarApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            using (SingleInstanceMutex sim = new SingleInstanceMutex())
            {

                if (sim.IsOtherInstanceRunning)
                {
                    //WriteTextToLocalDive("instance running");
                    //Process[] localByName = Process.GetProcessesByName("CalendarApp");
                    //foreach (Process p in localByName)
                    //{
                    //    WriteTextToLocalDive("Process Killing");
                    //    p.Kill();
                    //}
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new Form1(true));
                    //Application.Exit();

                }
                else
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run(new Form1(false));
                }
                //WriteTextToLocalDive("first instance running");
                

                
            }
            // WriteTextToLocalDive("first instance running");
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Form form1 = new Form1();
            //form1.Show();
            //Application.Run(form1);
            //form1.Hide();

            //this.Hide();

            //String thisprocessname = Process.GetCurrentProcess().ProcessName;
            //void WriteTextToLocalDive(string writeText)
            //{
            //    string _path = "F:/infoLog.txt";

            //    using (StreamWriter sw = File.AppendText(_path))
            //    {
            //        sw.WriteLine($"{DateTime.Now} ------ ExamResultRepository > {writeText}");
            //    }
            //}

            //if (Process.GetProcesses().Count(p => p.ProcessName == thisprocessname) > 1)
            //    return;

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);

            //Application.Run(new Form1());
        }
        
    }
    
}
