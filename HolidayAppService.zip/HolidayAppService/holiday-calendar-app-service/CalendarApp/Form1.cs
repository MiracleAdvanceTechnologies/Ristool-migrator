﻿using CalendarApp.Model;
using Microsoft.Win32;
using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace CalendarApp
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.ContextMenu contextMenu;
        private System.Windows.Forms.MenuItem menuItem;
        private System.Windows.Forms.MenuItem menuItemExit;
        private string localPath = "";
        public Form1(bool alreayExist)
        {
           
               
                if (alreayExist)
                {
                    WriteTextToLocalDive("If");

                    this.HideForm();
                    this.WindowState = FormWindowState.Minimized;
                    this.ShowInTaskbar = false;
                    //this.Hide();
                }
                else
                {
                    WriteTextToLocalDive("else");
                    InitializeComponent();

                    this.contextMenu = new System.Windows.Forms.ContextMenu();
                    this.menuItem = new System.Windows.Forms.MenuItem();
                    this.menuItemExit = new System.Windows.Forms.MenuItem();
                    this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                    this.menuItem,
                    this.menuItemExit});

                    this.menuItem.DefaultItem = true;
                    this.menuItem.Index = 0;
                    this.menuItem.Text = "Envision Holiday Config";
                    this.menuItem.Click += new System.EventHandler(this.menuItem_Click);

                    this.menuItemExit.Index = 1;
                    this.menuItemExit.Text = "Exit";
                    this.menuItemExit.Click += new System.EventHandler(this.menuItemExit_Click);

                    SetInitValues();
                }
            

        }
        private void HideForm()
        {
           
            //Hide();
            //this.Close();
            //foreach (Form var in Application.OpenForms)
            //{
            //    var.Hide();
            //}
            var aForm = new CalendarSetupForm();
            aForm.Show();
            //this.Hide();

        }
        private void SetInitValues()
        {

            RegHelper reg = new RegHelper();
            //appIcon = new Icon(GetType(), "D:\\EnvisionTaskScheduler\\EnvisionTaskScheduler\\TaskScheduler\\App.ico");
            localPath = System.Environment.CurrentDirectory;
            localPath += "\\" + Assembly.GetExecutingAssembly().GetName().Name +
                    ".exe";

            try
            {
                RegistryKey key;
                if (Environment.Is64BitOperatingSystem)
                {
                    key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run", false);
                }
                else
                {
                    key = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", false);
                }

                if (key.GetValue("calendarAppKey") == null)
                    RegHelper.SetRunOnStartup(localPath, false);
            }
            catch (NullReferenceException)
            {
            }


            this.WindowState = FormWindowState.Minimized;

            this.Hide();

            this.ShowInTaskbar = false;


            if (WindowState == FormWindowState.Minimized)
            {
                Hide();
                notifyIcon.ContextMenu = this.contextMenu;
                notifyIcon.BalloonTipTitle = "Envision Holiday App";
                notifyIcon.BalloonTipText = "Your application is running at taskbar.";
                notifyIcon.ShowBalloonTip(3000);

                foreach (Form var in Application.OpenForms)
                {
                    var.Hide();
                }
                //using (SingleInstanceMutex sim = new SingleInstanceMutex())
                //{

                //    if (sim.IsOtherInstanceRunning)
                //    {


                //    }
                //}
                this.Hide();
                var aForm = new CalendarSetupForm();
                aForm.Show();
                //this.Close();
            }


        }
        void WriteTextToLocalDive(string writeText)
        {
            string _path = "F:/infoLog.txt";

            using (StreamWriter sw = File.AppendText(_path))
            {
                sw.WriteLine($"{DateTime.Now} ------  > {writeText}");
            }
        }
        private void menuItem_Click(object sender, System.EventArgs e)
        {
            //foreach (Form var in Application.OpenForms)
            //{
            //    var.Hide();
            //}
            //var form3 = new CalendarSetupForm();
            //form3.Show();


            //var aForm = new CalendarSetupForm();
            //aForm.Show();
            //this.Close();
        }

        private void menuItemExit_Click(object sender, System.EventArgs e)
        {

            this.Close();
        }

        //private void Form1_Load(object sender, EventArgs e)
        //{
        //    this.Hide();
        //}
    }
}
