﻿using CalendarApp.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Net;
using System.Windows.Forms;

namespace CalendarApp
{
    public partial class CalendarSetupForm : Form
    {
        public CalendarSetupForm()
        {
            InitializeComponent();
            OfficeTimeSetupCheck();
        }

        private void OfficeTimeSetupCheck()
        {
            // For Monday
            if (this.MondayCheckBox.Checked == false)
            {
                this.MondayStartTime.Enabled = false;
                this.MondayStartTime.Font = new Font(this.MondayStartTime.Font, FontStyle.Strikeout);

                this.MondayEndTime.Enabled = false;
                this.MondayEndTime.Font = new Font(this.MondayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.MondayStartTime.Enabled = true;
                this.MondayStartTime.Font = new Font(this.MondayStartTime.Font, FontStyle.Regular);

                this.MondayEndTime.Enabled = true;
                this.MondayEndTime.Font = new Font(this.MondayEndTime.Font, FontStyle.Regular);
            }

            // For Tuesday
            if (this.TuesdayCheckBox.Checked == false)
            {
                this.TuesDayStartTime.Enabled = false;
                this.TuesDayStartTime.Font = new Font(this.TuesDayStartTime.Font, FontStyle.Strikeout);

                this.TuesdayEndTime.Enabled = false;
                this.TuesdayEndTime.Font = new Font(this.TuesdayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.TuesDayStartTime.Enabled = true;
                this.TuesDayStartTime.Font = new Font(this.TuesDayStartTime.Font, FontStyle.Regular);

                this.TuesdayEndTime.Enabled = true;
                this.TuesdayEndTime.Font = new Font(this.TuesdayEndTime.Font, FontStyle.Regular);
            }

            // For Wednesday
            if (this.WednesdayCheckBox.Checked == false)
            {
                this.WednesDayStartTime.Enabled = false;
                this.WednesDayStartTime.Font = new Font(this.WednesDayStartTime.Font, FontStyle.Strikeout);

                this.WednesdayEndTime.Enabled = false;
                this.WednesdayEndTime.Font = new Font(this.WednesdayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.WednesDayStartTime.Enabled = true;
                this.WednesDayStartTime.Font = new Font(this.WednesDayStartTime.Font, FontStyle.Regular);

                this.WednesdayEndTime.Enabled = true;
                this.WednesdayEndTime.Font = new Font(this.WednesdayEndTime.Font, FontStyle.Regular);
            }

            // For Thursday
            if (this.ThursdayCheckBox.Checked == false)
            {
                this.ThursDayStartTime.Enabled = false;
                this.ThursDayStartTime.Font = new Font(this.ThursDayStartTime.Font, FontStyle.Strikeout);

                this.ThursdayEndTime.Enabled = false;
                this.ThursdayEndTime.Font = new Font(this.ThursdayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.ThursDayStartTime.Enabled = true;
                this.ThursDayStartTime.Font = new Font(this.ThursDayStartTime.Font, FontStyle.Regular);

                this.ThursdayEndTime.Enabled = true;
                this.ThursdayEndTime.Font = new Font(this.ThursdayEndTime.Font, FontStyle.Regular);
            }

            // For Friday
            if (this.FridayCheckBox.Checked == false)
            {
                this.FriDayStartTime.Enabled = false;
                this.FriDayStartTime.Font = new Font(this.FriDayStartTime.Font, FontStyle.Strikeout);

                this.FridayEndTime.Enabled = false;
                this.FridayEndTime.Font = new Font(this.FridayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.FriDayStartTime.Enabled = true;
                this.FriDayStartTime.Font = new Font(this.FriDayStartTime.Font, FontStyle.Regular);

                this.FridayEndTime.Enabled = true;
                this.FridayEndTime.Font = new Font(this.FridayEndTime.Font, FontStyle.Regular);
            }

            // For Saturday
            if (this.SaturdayCheckBox.Checked == false)
            {
                this.SaturDayStartTime.Enabled = false;
                this.SaturDayStartTime.Font = new Font(this.SaturDayStartTime.Font, FontStyle.Strikeout);

                this.SaturdayEndTime.Enabled = false;
                this.SaturdayEndTime.Font = new Font(this.SaturdayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.SaturDayStartTime.Enabled = true;
                this.SaturDayStartTime.Font = new Font(this.SaturDayStartTime.Font, FontStyle.Regular);

                this.SaturdayEndTime.Enabled = true;
                this.SaturdayEndTime.Font = new Font(this.SaturdayEndTime.Font, FontStyle.Regular);
            }

            // For Sunday
            if (this.SundayCheckBox.Checked == false)
            {
                this.SunDayStartTime.Enabled = false;
                this.SunDayStartTime.Font = new Font(this.SunDayStartTime.Font, FontStyle.Strikeout);

                this.SunDayEndTime.Enabled = false;
                this.SunDayEndTime.Font = new Font(this.SunDayEndTime.Font, FontStyle.Strikeout);
            }
            else
            {
                this.SunDayStartTime.Enabled = true;
                this.SunDayStartTime.Font = new Font(this.SunDayStartTime.Font, FontStyle.Regular);

                this.SunDayEndTime.Enabled = true;
                this.SunDayEndTime.Font = new Font(this.SunDayEndTime.Font, FontStyle.Regular);
            }
        }

        private void UploadBtn_Click(object sender, EventArgs e)
        {
            if (this.urlTextBox.Text != null && this.urlTextBox.Text != "")
            {
                this.uploadCalendar(urlTextBox.Text, false);
            }
            else
            {
                MessageBox.Show("Please Insert URL");
            }
        }

        private void uploadCalendar(string url, bool forUpdate)
        {
            StreamReader sr;
            try
            {
                string filePath = url;
                //IFormFile file;
                var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                //var fileSavepath = config.AppSettings.Settings["fileSavePath"].Value;
                var fileSavepath = AppDomain.CurrentDomain.BaseDirectory + "\\CALENDAR_FILES\\";
                bool exists = System.IO.Directory.Exists(fileSavepath); ;
                if (!exists)
                {
                    System.IO.Directory.CreateDirectory(fileSavepath);
                }
                WebClient myWebClient = new WebClient();
                string savePath = @fileSavepath + this.randomName() + ".ics";

                myWebClient.DownloadFile(filePath, savePath);
                var folderName = Path.Combine("Resources", "Calenders");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
                DateTime dateStart = new DateTime();
                DateTime dateEnd = new DateTime();
                List<VCalendarModel> jsonHolidayList = new List<VCalendarModel>();
                List<VCalendarModel> jsonHolidayList2 = new List<VCalendarModel>();
                string description = "";
                using (sr = new StreamReader(@savePath, System.Text.Encoding.UTF8))
                {
                    string ical = sr.ReadToEnd();

                    char[] delim = { '\n' };
                    string[] lines = ical.Split(delim);
                    delim[0] = ':';
                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (lines[i].Contains("DTSTART"))
                        {
                            var aLine = lines[i].Contains("DTSTART");

                            if (lines[i].Contains("DTSTART;VALUE=DATE:"))
                            {
                                string[] targetSplitWord = { "DATE:" };
                                var aData = lines[i].Split(targetSplitWord, 2, StringSplitOptions.None);
                                var year = aData[1].Substring(0, 4);
                                var month = aData[1].Substring(4, 2);
                                var day = aData[1].Substring(6, 2);
                                dateStart = new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day));

                            }
                            else
                            {
                                string[] targetSplitWord = { "DTSTART:" };
                                var aData = lines[i].Split(targetSplitWord, 2, StringSplitOptions.None);
                                var sortedData = aData[1].Split("\r".ToCharArray(), 2);
                                var datepart = sortedData[0].Split("T".ToCharArray(), 2);
                                var year = datepart[0].Substring(0, 4);
                                var month = datepart[0].Substring(4, 2);
                                var day = datepart[0].Substring(6, 2);
                                dateStart = new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day));
                                //dateStart = Convert.ToDateTime(sortedData[0]);// new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day));
                            }
                        }

                        if (lines[i].Contains("DTEND"))
                        {
                            if (lines[i].Contains("DTEND;VALUE=DATE:"))
                            {
                                string[] targetSplitWord = { "DATE:" };
                                var aData = lines[i].Split(targetSplitWord, 2, StringSplitOptions.None);
                                var year = aData[1].Substring(0, 4);
                                var month = aData[1].Substring(4, 2);
                                var day = aData[1].Substring(6, 2);
                                dateEnd = new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day));

                            }
                            else
                            {
                                string[] targetSplitWord = { "DTEND:" };
                                var aData = lines[i].Split(targetSplitWord, 2, StringSplitOptions.None);
                                var sortedData = aData[1].Split("\r".ToCharArray(), 2);
                                var datepart = sortedData[0].Split("T".ToCharArray(), 2);
                                var year = datepart[0].Substring(0, 4);
                                var month = datepart[0].Substring(4, 2);
                                var day = datepart[0].Substring(6, 2);
                                dateEnd = new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day));
                                //dateStart = Convert.ToDateTime(sortedData[0]);// new DateTime(Convert.ToInt32(year), Convert.ToInt32(month), Convert.ToInt32(day));
                            }
                        }

                        if (lines[i].Contains("DESCRIPTION"))
                        {
                            string[] targetSplitWord = { "DESCRIPTION:" };
                            var aData = lines[i].Split(targetSplitWord, 2, StringSplitOptions.None);
                            var sortedData = aData[1].Split("\r".ToCharArray(), 2);
                            description = sortedData[0];
                        }

                        if (lines[i].Contains("END:VEVENT"))
                        {
                            VCalendarModel calendarModel = new VCalendarModel();
                            calendarModel.startDate = dateStart;
                            calendarModel.endDate = dateEnd;
                            calendarModel.description = description;
                            jsonHolidayList.Add(calendarModel);
                            dateStart = new DateTime();
                            dateEnd = new DateTime();
                            description = "";
                        }
                    }
                    foreach (var item in jsonHolidayList)
                    {
                        var days = (item.endDate - item.startDate).Days;
                        if (days > 1)
                        {
                            for (int i = 0; i < days; i++)
                            {
                                GblHoliday holiday = new GblHoliday();
                                holiday.HolidayDate = item.startDate.AddDays(i);
                                holiday.HolidayDesc = item.description;
                                holiday.IsActive = true;
                                holiday.CreatedOn = System.DateTime.Now;
                                holiday.LastModifiedOn = System.DateTime.Now;
                                SaveHoliday(holiday);
                                //holiday.OrgId = 0;
                                //holiday.CreatedBy = 0;
                            }
                        }
                        else
                        {
                            GblHoliday holiday = new GblHoliday();
                            holiday.HolidayDate = item.startDate;
                            holiday.HolidayDesc = item.description;
                            holiday.IsActive = true;
                            holiday.CreatedOn = System.DateTime.Now;
                            holiday.LastModifiedOn = System.DateTime.Now;
                            SaveHoliday(holiday);
                        }

                    }
                    this.SaveURLToEnv(filePath, forUpdate);
                    //this.urlTextBox.Text = "";

                    //jsonHolidayList2 = jsonHolidayList;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Import Failed " + ex.Message.ToString());
                //throw ex;
            }
        }
        private string randomName()
        {
            char[] letters = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
            Random r = new Random();
            string randomString = "";
            for (int i = 0; i < 10; i++)
            {
                randomString += letters[r.Next(0, 26)].ToString();
            }
            return randomString;

        }
        public void SaveURLToEnv(string url, bool forUpdate)
        {
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            string query = "update GBL_ENV set CALENDAR_URL=@CALENDAR_URL,LAST_UPDATE_TIME=@TODAY where ORG_ID=1";
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;
                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@CALENDAR_URL", url);
                    com.Parameters.AddWithValue("@TODAY", System.DateTime.Now);
                    rows = com.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        if (forUpdate != true)
                        {

                            MessageBox.Show("Import Successfull");
                        }
                        this.getLastImportTIme();
                        //this.Close();
                    }
                }

            }
        }

        public void SaveHoliday(GblHoliday gblHoliday)
        {
            bool isExist = this.isExist(gblHoliday.HolidayDate ?? new DateTime());
            if (!isExist)
            {
                string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
                // string query = "INSERT INTO dbo.GBL_HOLIDAY(HOLIDAY_DATE,HOLIDAY_DESC,IS_ACTIVE,ORG_ID,CREATED_BY,CREATED_ON,LAST_MODIFIED_BY,LAST_MODIFIED_ON) VALUES(@HOLIDAY_DATE,@HOLIDAY_DESC,@IS_ACTIVE,@ORG_ID,@CREATED_BY,@CREATED_ON,@LAST_MODIFIED_BY,@LAST_MODIFIED_ON)";
                string query = "INSERT INTO dbo.GBL_HOLIDAY(HOLIDAY_DATE,HOLIDAY_DESC,IS_ACTIVE,CREATED_ON,LAST_MODIFIED_ON) VALUES (@HOLIDAY_DATE,@HOLIDAY_DESC,@IS_ACTIVE,@CREATED_ON,@LAST_MODIFIED_ON)";
                using (SqlConnection con = new SqlConnection(myConn))
                {
                    con.Open();
                    int rows;
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        com.Parameters.AddWithValue("@HOLIDAY_DATE", gblHoliday.HolidayDate);
                        com.Parameters.AddWithValue("@HOLIDAY_DESC", gblHoliday.HolidayDesc);
                        com.Parameters.AddWithValue("@IS_ACTIVE", gblHoliday.IsActive);
                        //com.Parameters.AddWithValue("@CREATED_BY", gblHoliday.CreatedBy);
                        com.Parameters.AddWithValue("@CREATED_ON", gblHoliday.CreatedOn);
                        //com.Parameters.AddWithValue("@LAST_MODIFIED_BY", gblHoliday.LastModifiedBy);
                        com.Parameters.AddWithValue("@LAST_MODIFIED_ON", gblHoliday.LastModifiedOn);
                        //com.Parameters.AddWithValue("@ORG_ID", gblHoliday.OrgId);


                        rows = com.ExecuteNonQuery();
                    }
                }
            }
        }
        private bool isExist(DateTime dateTime)
        {
            var onlyDate = dateTime.ToString("yyyy-MM-dd");
            SqlDataReader reader;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                string query = "select * from GBL_HOLIDAY where CAST(isnull(HOLIDAY_DATE,GETDATE()) as date) =@onlyDate";
                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@onlyDate", onlyDate);
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        return true;
                    }
                }
                return false;
            }
        }



        private void saveBtn_Click(object sender, EventArgs e)
        {
            string dayName;
            //monday
            dayName = "MONDAY";
            TimeSpan stime = this.MondayStartTime.Value.TimeOfDay;
            TimeSpan etime = this.MondayEndTime.Value.TimeOfDay;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            string query = "UPDATE dbo.GBL_OFFICETIME SET START_TIME=@START_TIME,END_TIME=@END_TIME,IS_ACTIVE=@IS_ACTIVE WHERE DAY_NAME=@DAY_NAME";
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", stime);
                    com.Parameters.AddWithValue("@END_TIME", etime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.MondayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                }
            }

            //tuesday
            dayName = "TUESDAY";
            TimeSpan tuesdayStartTime = this.TuesDayStartTime.Value.TimeOfDay;
            TimeSpan tuesdayEndTime = this.TuesdayEndTime.Value.TimeOfDay;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", tuesdayStartTime);
                    com.Parameters.AddWithValue("@END_TIME", tuesdayEndTime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.TuesdayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                }
            }

            //wednesday
            dayName = "WEDNESDAY";
            TimeSpan wednesdayStartTime = this.WednesDayStartTime.Value.TimeOfDay;
            TimeSpan wednesdayEndTime = this.WednesdayEndTime.Value.TimeOfDay;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", wednesdayStartTime);
                    com.Parameters.AddWithValue("@END_TIME", wednesdayEndTime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.WednesdayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                }
            }

            //thursday
            dayName = "THURSDAY";
            TimeSpan thursdayStartTime = this.ThursDayStartTime.Value.TimeOfDay;
            TimeSpan thursdayEndTime = this.ThursdayEndTime.Value.TimeOfDay;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", thursdayStartTime);
                    com.Parameters.AddWithValue("@END_TIME", thursdayEndTime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.ThursdayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                }
            }

            //friday
            dayName = "FRIDAY";
            TimeSpan fridayStartTime = this.FriDayStartTime.Value.TimeOfDay;
            TimeSpan fridayEndTime = this.FridayEndTime.Value.TimeOfDay;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", fridayStartTime);
                    com.Parameters.AddWithValue("@END_TIME", fridayEndTime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.FridayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                }
            }

            //saturday
            dayName = "SATURDAY";
            TimeSpan saturdayStartTime = this.SaturDayStartTime.Value.TimeOfDay;
            TimeSpan saturdayEndTime = this.SaturdayEndTime.Value.TimeOfDay;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", saturdayStartTime);
                    com.Parameters.AddWithValue("@END_TIME", saturdayEndTime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.SaturdayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                }
            }

            //sunday
            dayName = "SUNDAY";
            TimeSpan sundayStartTime = this.SunDayStartTime.Value.TimeOfDay;
            TimeSpan sundayEndTime = this.SunDayEndTime.Value.TimeOfDay;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                int rows;

                using (SqlCommand com = new SqlCommand(query, con))
                {
                    com.Parameters.AddWithValue("@START_TIME", sundayStartTime);
                    com.Parameters.AddWithValue("@END_TIME", sundayEndTime);
                    com.Parameters.AddWithValue("@DAY_NAME", dayName);
                    com.Parameters.AddWithValue("@IS_ACTIVE", this.SundayCheckBox.Checked);
                    rows = com.ExecuteNonQuery();
                    if (rows > 0)
                    {
                        MessageBox.Show("Save Successfull");
                    }
                }
            }



        }

        private void CalendarSetupForm_Load(object sender, EventArgs e)
        {
            this.setAutoUpdateData();
            SqlDataReader reader;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                string query = "select * from GBL_OFFICETIME";
                using (SqlCommand com = new SqlCommand(query, con))
                {
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader["DAY_NAME"].ToString() == "MONDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.MondayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.MondayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.MondayCheckBox.Checked = false;
                                this.MondayStartTime.Enabled = false;
                                this.MondayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.MondayCheckBox.Checked = true;

                            }
                        }
                        if (reader["DAY_NAME"].ToString() == "TUESDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.TuesDayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.TuesdayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.TuesdayCheckBox.Checked = false;
                                this.TuesDayStartTime.Enabled = false;
                                this.TuesdayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.TuesdayCheckBox.Checked = true;

                            }
                        }
                        if (reader["DAY_NAME"].ToString() == "WEDNESDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.WednesDayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.WednesdayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.WednesdayCheckBox.Checked = false;
                                this.WednesDayStartTime.Enabled = false;
                                this.WednesdayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.WednesdayCheckBox.Checked = true;

                            }
                        }
                        if (reader["DAY_NAME"].ToString() == "THURSDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.ThursDayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.ThursdayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.ThursdayCheckBox.Checked = false;
                                this.ThursDayStartTime.Enabled = false;
                                this.ThursdayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.ThursdayCheckBox.Checked = true;

                            }
                        }
                        if (reader["DAY_NAME"].ToString() == "FRIDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.FriDayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.FridayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.FridayCheckBox.Checked = false;
                                this.FriDayStartTime.Enabled = false;
                                this.FridayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.FridayCheckBox.Checked = true;

                            }
                        }
                        if (reader["DAY_NAME"].ToString() == "SATURDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.SaturDayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.SaturdayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.SaturdayCheckBox.Checked = false;
                                this.SaturDayStartTime.Enabled = false;
                                this.SaturdayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.SaturdayCheckBox.Checked = true;

                            }
                        }

                        if (reader["DAY_NAME"].ToString() == "SUNDAY")
                        {
                            DateTime Stime = Convert.ToDateTime(reader["START_TIME"].ToString());
                            this.SunDayStartTime.Value = Stime;
                            DateTime Etime = Convert.ToDateTime(reader["END_TIME"].ToString());
                            this.SunDayEndTime.Value = Etime;
                            if (reader["IS_ACTIVE"].ToString() == "0")
                            {
                                this.SundayCheckBox.Checked = false;
                                this.SunDayStartTime.Enabled = false;
                                this.SunDayEndTime.Enabled = false;
                            }
                            else
                            {
                                this.SundayCheckBox.Checked = true;

                            }
                        }

                    }
                }

            }
        }
        private void setAutoUpdateData()
        {
            SqlDataReader reader;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                string query = "select * from GBL_ENV where ORG_ID=1";
                using (SqlCommand com = new SqlCommand(query, con))
                {
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        if ((reader["CALENDAR_URL"].ToString() != null))
                        {
                            this.urlTextBox.Text = reader["CALENDAR_URL"].ToString();
                        }

                        if (Convert.ToInt32(reader["AUTO_UPDATE"]) == 0)
                        {
                            this.noCheckBox.Checked = true;
                            this.lastUpdateGroupBox.Enabled = false;
                        }
                        if (Convert.ToInt32(reader["AUTO_UPDATE"]) == 1)
                        {
                            this.yesCheckBox.Checked = true;
                            //this.lastUpdateGroupBox.Visible = true;
                            if (reader["LAST_UPDATE_TIME"].ToString() != null && reader["CALENDAR_URL"].ToString() != null && reader["CALENDAR_URL"].ToString() != "")
                            {
                                this.lastImportLabel.Text = reader["LAST_UPDATE_TIME"].ToString();
                            }
                            if (Convert.ToInt32(reader["FREQUENCY"]) == 1)
                            {
                                this.checkBox1month.Checked = true;
                            }
                            if (Convert.ToInt32(reader["FREQUENCY"]) == 3)
                            {
                                this.checkBox3month.Checked = true;
                            }
                            if (Convert.ToInt32(reader["FREQUENCY"]) == 6)
                            {
                                this.checkBox6month.Checked = true;
                            }
                            if (Convert.ToInt32(reader["FREQUENCY"]) == 12)
                            {
                                this.checkBox12month.Checked = true;
                            }

                        }

                    }

                }
            }
        }
        private void MondayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void TuesdayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void WednesdayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void ThursdayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void FridayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void SaturdayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void SundayCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OfficeTimeSetupCheck();
        }

        private void yesCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.yesCheckBox.Checked == true)
            {
                this.noCheckBox.Checked = false;
                this.frequencyPanel.Enabled = true;
                this.lastUpdateGroupBox.Enabled = true;

            }
            if (this.yesCheckBox.Checked == false)
            {
                this.frequencyPanel.Enabled = false;
                this.lastUpdateGroupBox.Enabled = false;

            }
            this.setfrequencySaveButtonEnableStatus();
        }

        private void noCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (this.noCheckBox.Checked == true)
            {
                this.yesCheckBox.Checked = false;
                this.frequencyPanel.Enabled = false;
                this.lastUpdateGroupBox.Enabled = false;



            }
            this.setfrequencySaveButtonEnableStatus();

        }
        public void setfrequencySaveButtonEnableStatus()
        {
            this.frequencySaveButton.Enabled = false;
            if (this.noCheckBox.Checked == true)
            {
                this.frequencySaveButton.Enabled = true;
            }
            if (this.yesCheckBox.Checked == true)
            {
                if (this.checkBox1month.Checked == true || this.checkBox3month.Checked == true ||
                    this.checkBox6month.Checked == true || this.checkBox12month.Checked == true)
                {
                    this.frequencySaveButton.Enabled = true;
                }
            }
        }

        private void checkBox1month_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox1month.Checked == true)
            {
                this.checkBox3month.Checked = false;
                this.checkBox6month.Checked = false;
                this.checkBox12month.Checked = false;
            }
            this.setfrequencySaveButtonEnableStatus();
        }

        private void checkBox3month_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox3month.Checked == true)
            {
                this.checkBox1month.Checked = false;
                this.checkBox6month.Checked = false;
                this.checkBox12month.Checked = false;
            }
            this.setfrequencySaveButtonEnableStatus();
        }

        private void checkBox6month_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox6month.Checked == true)
            {
                this.checkBox1month.Checked = false;
                this.checkBox3month.Checked = false;
                this.checkBox12month.Checked = false;
            }
            this.setfrequencySaveButtonEnableStatus();
        }

        private void checkBox12month_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox12month.Checked == true)
            {
                this.checkBox1month.Checked = false;
                this.checkBox3month.Checked = false;
                this.checkBox6month.Checked = false;
            }
            this.setfrequencySaveButtonEnableStatus();
        }

        private int getFrequency()
        {
            int month;
            if (this.checkBox1month.Checked == true)
            { return 1; }
            else if (this.checkBox3month.Checked == true)
            { return 3; }
            else if (this.checkBox6month.Checked == true)
            { return 6; }
            else if (this.checkBox12month.Checked == true)
            { return 12; }
            else
            { return 0; }
        }
        private void frequencySaveButton_Click(object sender, EventArgs e)
        {
            string query;
            int rows;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            if (this.noCheckBox.Checked == true)
            {
                query = "update GBL_ENV set AUTO_UPDATE=0,FREQUENCY=0 where ORG_ID=1";
                using (SqlConnection con = new SqlConnection(myConn))
                {
                    con.Open();


                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        rows = com.ExecuteNonQuery();
                    }
                }
                this.updateTimer.Enabled = false;
                this.clearData();
            }
            else
            {
                int month = this.getFrequency();
                query = "update GBL_ENV set AUTO_UPDATE=1,FREQUENCY=@FREQUENCY,LAST_UPDATE_TIME=@LAST_UPDATE_TIME where ORG_ID=1";
                using (SqlConnection con = new SqlConnection(myConn))
                {
                    con.Open();
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        com.Parameters.AddWithValue("@FREQUENCY", month);
                        com.Parameters.AddWithValue("@LAST_UPDATE_TIME", System.DateTime.Now);
                        rows = com.ExecuteNonQuery();
                    }
                }
            }
            if (rows > 0)
            {
                this.updateTimer.Enabled = true;
                MessageBox.Show("Save Successfull");
            }


        }
        private void clearData()
        {
            this.checkBox1month.Checked = false;
            this.checkBox3month.Checked = false;
            this.checkBox6month.Checked = false;
            this.checkBox12month.Checked = false;
        }

        private void updateTimer_Tick(object sender, EventArgs e)
        {
            SqlDataReader reader;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                string query = "select * from GBL_ENV where ORG_ID=1";
                using (SqlCommand com = new SqlCommand(query, con))
                {
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        bool autoUpdate = Convert.ToBoolean(reader["AUTO_UPDATE"]);
                        if (autoUpdate)
                        {
                            DateTime lastUpdateday = new DateTime();
                            lastUpdateday = Convert.ToDateTime(reader["LAST_UPDATE_TIME"]);
                            DateTime nextUpdateDate = new DateTime();
                            nextUpdateDate = lastUpdateday.AddMonths(Convert.ToInt32(reader["FREQUENCY"]));
                            if (System.DateTime.Now.Date > nextUpdateDate.Date)
                            {
                                if (reader["CALENDAR_URL"] != null)
                                {
                                    this.uploadCalendar(reader["CALENDAR_URL"].ToString(), true);
                                    //this.getLastImportTIme();


                                }
                            }
                        }
                    }
                }
            }
        }
        private void getLastImportTIme()
        {
            SqlDataReader reader;
            string myConn = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(myConn))
            {
                con.Open();
                string query = "select * from GBL_ENV where ORG_ID=1";
                using (SqlCommand com = new SqlCommand(query, con))
                {
                    reader = com.ExecuteReader();
                    while (reader.Read())
                    {
                        if (reader["LAST_UPDATE_TIME"].ToString() != null && reader["CALENDAR_URL"].ToString() != null)
                        {
                            this.lastImportLabel.Text = reader["LAST_UPDATE_TIME"].ToString();
                        }
                        // this.lastImportLabel.Text = reader["LAST_UPDATE_TIME"].ToString();

                    }
                }
            }
        }

        private void SunDayStartTime_ValueChanged(object sender, EventArgs e)
        {

        }


    }
}


